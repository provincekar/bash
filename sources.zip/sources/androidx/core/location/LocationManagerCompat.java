package androidx.core.location;

import android.content.Context;
import android.location.GnssStatus;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import androidx.collection.SimpleArrayMap;
import androidx.core.location.GnssStatusCompat;
import androidx.core.os.CancellationSignal;
import androidx.core.os.ExecutorCompat;
import androidx.core.util.Consumer;
import androidx.core.util.Preconditions;
import java.lang.reflect.Field;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final class LocationManagerCompat {
    private static final long GET_CURRENT_LOCATION_TIMEOUT_MS = 30000;
    private static final long MAX_CURRENT_LOCATION_AGE_MS = 10000;
    private static final long PRE_N_LOOPER_TIMEOUT_S = 5;
    private static Field sContextField;
    private static final SimpleArrayMap sGnssStatusListeners = new SimpleArrayMap();

    public static boolean isLocationEnabled(LocationManager locationManager) {
        if (Build.VERSION.SDK_INT >= 28) {
            return Api28Impl.isLocationEnabled(locationManager);
        }
        if (Build.VERSION.SDK_INT <= 19) {
            try {
                if (sContextField == null) {
                    Field declaredField = LocationManager.class.getDeclaredField("mContext");
                    sContextField = declaredField;
                    declaredField.setAccessible(true);
                }
                Context context = (Context) sContextField.get(locationManager);
                if (context != null) {
                    if (Build.VERSION.SDK_INT == 19) {
                        return Settings.Secure.getInt(context.getContentResolver(), "location_mode", 0) != 0;
                    }
                    return !TextUtils.isEmpty(Settings.Secure.getString(context.getContentResolver(), "location_providers_allowed"));
                }
            } catch (ClassCastException | SecurityException | NoSuchFieldException | IllegalAccessException unused) {
            }
        }
        return locationManager.isProviderEnabled("network") || locationManager.isProviderEnabled("gps");
    }

    public static void getCurrentLocation(LocationManager locationManager, String provider, CancellationSignal cancellationSignal, Executor executor, final Consumer consumer) {
        if (Build.VERSION.SDK_INT >= 30) {
            Api30Impl.getCurrentLocation(locationManager, provider, cancellationSignal, executor, consumer);
            return;
        }
        if (cancellationSignal != null) {
            cancellationSignal.throwIfCanceled();
        }
        Location lastKnownLocation = locationManager.getLastKnownLocation(provider);
        if (lastKnownLocation != null && SystemClock.elapsedRealtime() - LocationCompat.getElapsedRealtimeMillis(lastKnownLocation) < 10000) {
            executor.execute(new 1(consumer, lastKnownLocation));
            return;
        }
        CancellableLocationListener cancellableLocationListener = new CancellableLocationListener(locationManager, executor, consumer);
        locationManager.requestLocationUpdates(provider, 0L, 0.0f, cancellableLocationListener, Looper.getMainLooper());
        if (cancellationSignal != null) {
            cancellationSignal.setOnCancelListener(new 2(cancellableLocationListener));
        }
        cancellableLocationListener.startTimeout(30000L);
    }

    class 1 implements Runnable {
        final /* synthetic */ Consumer val$consumer;
        final /* synthetic */ Location val$location;

        1(final Consumer val$consumer, final Location val$location) {
            this.val$consumer = val$consumer;
            this.val$location = val$location;
        }

        public void run() {
            this.val$consumer.accept(this.val$location);
        }
    }

    class 2 implements CancellationSignal.OnCancelListener {
        final /* synthetic */ CancellableLocationListener val$listener;

        2(final CancellableLocationListener val$listener) {
            this.val$listener = val$listener;
        }

        public void onCancel() {
            this.val$listener.cancel();
        }
    }

    public static String getGnssHardwareModelName(LocationManager locationManager) {
        if (Build.VERSION.SDK_INT >= 28) {
            return Api28Impl.getGnssHardwareModelName(locationManager);
        }
        return null;
    }

    public static int getGnssYearOfHardware(LocationManager locationManager) {
        if (Build.VERSION.SDK_INT >= 28) {
            return Api28Impl.getGnssYearOfHardware(locationManager);
        }
        return 0;
    }

    public static boolean registerGnssStatusCallback(LocationManager locationManager, GnssStatusCompat.Callback callback, Handler handler) {
        if (Build.VERSION.SDK_INT >= 30) {
            return registerGnssStatusCallback(locationManager, ExecutorCompat.create(handler), callback);
        }
        return registerGnssStatusCallback(locationManager, new InlineHandlerExecutor(handler), callback);
    }

    public static boolean registerGnssStatusCallback(LocationManager locationManager, Executor executor, GnssStatusCompat.Callback callback) {
        if (Build.VERSION.SDK_INT >= 30) {
            return registerGnssStatusCallback(locationManager, null, executor, callback);
        }
        Looper myLooper = Looper.myLooper();
        if (myLooper == null) {
            myLooper = Looper.getMainLooper();
        }
        return registerGnssStatusCallback(locationManager, new Handler(myLooper), executor, callback);
    }

    /* JADX WARN: Removed duplicated region for block: B:79:0x010e A[Catch: all -> 0x012a, TryCatch #6 {all -> 0x012a, blocks: (B:73:0x00eb, B:74:0x0103, B:77:0x0106, B:79:0x010e, B:81:0x0116, B:82:0x011c, B:83:0x011d, B:84:0x0122, B:85:0x0123, B:86:0x0129, B:87:0x00da), top: B:53:0x009a }] */
    /* JADX WARN: Removed duplicated region for block: B:85:0x0123 A[Catch: all -> 0x012a, TryCatch #6 {all -> 0x012a, blocks: (B:73:0x00eb, B:74:0x0103, B:77:0x0106, B:79:0x010e, B:81:0x0116, B:82:0x011c, B:83:0x011d, B:84:0x0122, B:85:0x0123, B:86:0x0129, B:87:0x00da), top: B:53:0x009a }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static boolean registerGnssStatusCallback(final android.location.LocationManager r9, android.os.Handler r10, java.util.concurrent.Executor r11, androidx.core.location.GnssStatusCompat.Callback r12) {
        /*
            Method dump skipped, instructions count: 337
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.location.LocationManagerCompat.registerGnssStatusCallback(android.location.LocationManager, android.os.Handler, java.util.concurrent.Executor, androidx.core.location.GnssStatusCompat$Callback):boolean");
    }

    class 3 implements Callable {
        final /* synthetic */ LocationManager val$locationManager;
        final /* synthetic */ GpsStatusTransport val$myTransport;

        3(final LocationManager val$locationManager, final GpsStatusTransport val$myTransport) {
            this.val$locationManager = val$locationManager;
            this.val$myTransport = val$myTransport;
        }

        public Boolean call() {
            return Boolean.valueOf(this.val$locationManager.addGpsStatusListener(this.val$myTransport));
        }
    }

    public static void unregisterGnssStatusCallback(LocationManager locationManager, GnssStatusCompat.Callback callback) {
        if (Build.VERSION.SDK_INT >= 30) {
            SimpleArrayMap simpleArrayMap = sGnssStatusListeners;
            synchronized (simpleArrayMap) {
                GnssStatusTransport gnssStatusTransport = (GnssStatusTransport) simpleArrayMap.remove(callback);
                if (gnssStatusTransport != null) {
                    locationManager.unregisterGnssStatusCallback(gnssStatusTransport);
                }
            }
            return;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            SimpleArrayMap simpleArrayMap2 = sGnssStatusListeners;
            synchronized (simpleArrayMap2) {
                PreRGnssStatusTransport preRGnssStatusTransport = (PreRGnssStatusTransport) simpleArrayMap2.remove(callback);
                if (preRGnssStatusTransport != null) {
                    preRGnssStatusTransport.unregister();
                    locationManager.unregisterGnssStatusCallback(preRGnssStatusTransport);
                }
            }
            return;
        }
        SimpleArrayMap simpleArrayMap3 = sGnssStatusListeners;
        synchronized (simpleArrayMap3) {
            GpsStatusTransport gpsStatusTransport = (GpsStatusTransport) simpleArrayMap3.remove(callback);
            if (gpsStatusTransport != null) {
                gpsStatusTransport.unregister();
                locationManager.removeGpsStatusListener(gpsStatusTransport);
            }
        }
    }

    private LocationManagerCompat() {
    }

    private static class GnssStatusTransport extends GnssStatus.Callback {
        final GnssStatusCompat.Callback mCallback;

        GnssStatusTransport(GnssStatusCompat.Callback callback) {
            Preconditions.checkArgument(callback != null, "invalid null callback");
            this.mCallback = callback;
        }

        public void onStarted() {
            this.mCallback.onStarted();
        }

        public void onStopped() {
            this.mCallback.onStopped();
        }

        public void onFirstFix(int ttffMillis) {
            this.mCallback.onFirstFix(ttffMillis);
        }

        public void onSatelliteStatusChanged(GnssStatus status) {
            this.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(status));
        }
    }

    private static class PreRGnssStatusTransport extends GnssStatus.Callback {
        final GnssStatusCompat.Callback mCallback;
        volatile Executor mExecutor;

        PreRGnssStatusTransport(GnssStatusCompat.Callback callback) {
            Preconditions.checkArgument(callback != null, "invalid null callback");
            this.mCallback = callback;
        }

        public void register(Executor executor) {
            Preconditions.checkArgument(executor != null, "invalid null executor");
            Preconditions.checkState(this.mExecutor == null);
            this.mExecutor = executor;
        }

        public void unregister() {
            this.mExecutor = null;
        }

        public void onStarted() {
            Executor executor = this.mExecutor;
            if (executor == null) {
                return;
            }
            executor.execute(new 1(executor));
        }

        class 1 implements Runnable {
            final /* synthetic */ Executor val$executor;

            1(final Executor val$executor) {
                this.val$executor = val$executor;
            }

            public void run() {
                if (PreRGnssStatusTransport.this.mExecutor != this.val$executor) {
                    return;
                }
                PreRGnssStatusTransport.this.mCallback.onStarted();
            }
        }

        public void onStopped() {
            Executor executor = this.mExecutor;
            if (executor == null) {
                return;
            }
            executor.execute(new 2(executor));
        }

        class 2 implements Runnable {
            final /* synthetic */ Executor val$executor;

            2(final Executor val$executor) {
                this.val$executor = val$executor;
            }

            public void run() {
                if (PreRGnssStatusTransport.this.mExecutor != this.val$executor) {
                    return;
                }
                PreRGnssStatusTransport.this.mCallback.onStopped();
            }
        }

        public void onFirstFix(final int ttffMillis) {
            Executor executor = this.mExecutor;
            if (executor == null) {
                return;
            }
            executor.execute(new 3(executor, ttffMillis));
        }

        class 3 implements Runnable {
            final /* synthetic */ Executor val$executor;
            final /* synthetic */ int val$ttffMillis;

            3(final Executor val$executor, final int val$ttffMillis) {
                this.val$executor = val$executor;
                this.val$ttffMillis = val$ttffMillis;
            }

            public void run() {
                if (PreRGnssStatusTransport.this.mExecutor != this.val$executor) {
                    return;
                }
                PreRGnssStatusTransport.this.mCallback.onFirstFix(this.val$ttffMillis);
            }
        }

        public void onSatelliteStatusChanged(final GnssStatus status) {
            Executor executor = this.mExecutor;
            if (executor == null) {
                return;
            }
            executor.execute(new 4(executor, status));
        }

        class 4 implements Runnable {
            final /* synthetic */ Executor val$executor;
            final /* synthetic */ GnssStatus val$status;

            4(final Executor val$executor, final GnssStatus val$status) {
                this.val$executor = val$executor;
                this.val$status = val$status;
            }

            public void run() {
                if (PreRGnssStatusTransport.this.mExecutor != this.val$executor) {
                    return;
                }
                PreRGnssStatusTransport.this.mCallback.onSatelliteStatusChanged(GnssStatusCompat.wrap(this.val$status));
            }
        }
    }

    private static class GpsStatusTransport implements GpsStatus.Listener {
        final GnssStatusCompat.Callback mCallback;
        volatile Executor mExecutor;
        private final LocationManager mLocationManager;

        GpsStatusTransport(LocationManager locationManager, GnssStatusCompat.Callback callback) {
            Preconditions.checkArgument(callback != null, "invalid null callback");
            this.mLocationManager = locationManager;
            this.mCallback = callback;
        }

        public void register(Executor executor) {
            Preconditions.checkState(this.mExecutor == null);
            this.mExecutor = executor;
        }

        public void unregister() {
            this.mExecutor = null;
        }

        public void onGpsStatusChanged(int event) {
            GpsStatus gpsStatus;
            Executor executor = this.mExecutor;
            if (executor == null) {
                return;
            }
            if (event == 1) {
                executor.execute(new 1(executor));
                return;
            }
            if (event == 2) {
                executor.execute(new 2(executor));
                return;
            }
            if (event != 3) {
                if (event == 4 && (gpsStatus = this.mLocationManager.getGpsStatus((GpsStatus) null)) != null) {
                    executor.execute(new 4(executor, GnssStatusCompat.wrap(gpsStatus)));
                    return;
                }
                return;
            }
            GpsStatus gpsStatus2 = this.mLocationManager.getGpsStatus((GpsStatus) null);
            if (gpsStatus2 != null) {
                executor.execute(new 3(executor, gpsStatus2.getTimeToFirstFix()));
            }
        }

        class 1 implements Runnable {
            final /* synthetic */ Executor val$executor;

            1(final Executor val$executor) {
                this.val$executor = val$executor;
            }

            public void run() {
                if (GpsStatusTransport.this.mExecutor != this.val$executor) {
                    return;
                }
                GpsStatusTransport.this.mCallback.onStarted();
            }
        }

        class 2 implements Runnable {
            final /* synthetic */ Executor val$executor;

            2(final Executor val$executor) {
                this.val$executor = val$executor;
            }

            public void run() {
                if (GpsStatusTransport.this.mExecutor != this.val$executor) {
                    return;
                }
                GpsStatusTransport.this.mCallback.onStopped();
            }
        }

        class 3 implements Runnable {
            final /* synthetic */ Executor val$executor;
            final /* synthetic */ int val$ttff;

            3(final Executor val$executor, final int val$ttff) {
                this.val$executor = val$executor;
                this.val$ttff = val$ttff;
            }

            public void run() {
                if (GpsStatusTransport.this.mExecutor != this.val$executor) {
                    return;
                }
                GpsStatusTransport.this.mCallback.onFirstFix(this.val$ttff);
            }
        }

        class 4 implements Runnable {
            final /* synthetic */ Executor val$executor;
            final /* synthetic */ GnssStatusCompat val$gnssStatus;

            4(final Executor val$executor, final GnssStatusCompat val$gnssStatus) {
                this.val$executor = val$executor;
                this.val$gnssStatus = val$gnssStatus;
            }

            public void run() {
                if (GpsStatusTransport.this.mExecutor != this.val$executor) {
                    return;
                }
                GpsStatusTransport.this.mCallback.onSatelliteStatusChanged(this.val$gnssStatus);
            }
        }
    }

    private static class Api30Impl {
        private Api30Impl() {
        }

        static void getCurrentLocation(LocationManager locationManager, String provider, CancellationSignal cancellationSignal, Executor executor, final Consumer consumer) {
            locationManager.getCurrentLocation(provider, cancellationSignal != null ? (android.os.CancellationSignal) cancellationSignal.getCancellationSignalObject() : null, executor, new 1(consumer));
        }

        class 1 implements java.util.function.Consumer {
            final /* synthetic */ Consumer val$consumer;

            1(final Consumer val$consumer) {
                this.val$consumer = val$consumer;
            }

            public void accept(Location location) {
                this.val$consumer.accept(location);
            }
        }
    }

    private static class Api28Impl {
        private Api28Impl() {
        }

        static boolean isLocationEnabled(LocationManager locationManager) {
            return locationManager.isLocationEnabled();
        }

        static String getGnssHardwareModelName(LocationManager locationManager) {
            return locationManager.getGnssHardwareModelName();
        }

        static int getGnssYearOfHardware(LocationManager locationManager) {
            return locationManager.getGnssYearOfHardware();
        }
    }

    private static final class CancellableLocationListener implements LocationListener {
        private Consumer mConsumer;
        private final Executor mExecutor;
        private final LocationManager mLocationManager;
        private final Handler mTimeoutHandler = new Handler(Looper.getMainLooper());
        Runnable mTimeoutRunnable;
        private boolean mTriggered;

        public void onProviderEnabled(String provider) {
        }

        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        CancellableLocationListener(LocationManager locationManager, Executor executor, Consumer consumer) {
            this.mLocationManager = locationManager;
            this.mExecutor = executor;
            this.mConsumer = consumer;
        }

        public void cancel() {
            synchronized (this) {
                if (this.mTriggered) {
                    return;
                }
                this.mTriggered = true;
                cleanup();
            }
        }

        public void startTimeout(long timeoutMs) {
            synchronized (this) {
                if (this.mTriggered) {
                    return;
                }
                1 r0 = new 1();
                this.mTimeoutRunnable = r0;
                this.mTimeoutHandler.postDelayed(r0, timeoutMs);
            }
        }

        class 1 implements Runnable {
            1() {
            }

            public void run() {
                CancellableLocationListener.this.mTimeoutRunnable = null;
                CancellableLocationListener.this.onLocationChanged(null);
            }
        }

        public void onProviderDisabled(String p) {
            onLocationChanged(null);
        }

        public void onLocationChanged(final Location location) {
            synchronized (this) {
                if (this.mTriggered) {
                    return;
                }
                this.mTriggered = true;
                this.mExecutor.execute(new 2(this.mConsumer, location));
                cleanup();
            }
        }

        class 2 implements Runnable {
            final /* synthetic */ Consumer val$consumer;
            final /* synthetic */ Location val$location;

            2(final Consumer val$consumer, final Location val$location) {
                this.val$consumer = val$consumer;
                this.val$location = val$location;
            }

            public void run() {
                this.val$consumer.accept(this.val$location);
            }
        }

        private void cleanup() {
            this.mConsumer = null;
            this.mLocationManager.removeUpdates(this);
            Runnable runnable = this.mTimeoutRunnable;
            if (runnable != null) {
                this.mTimeoutHandler.removeCallbacks(runnable);
                this.mTimeoutRunnable = null;
            }
        }
    }

    private static final class InlineHandlerExecutor implements Executor {
        private final Handler mHandler;

        InlineHandlerExecutor(Handler handler) {
            this.mHandler = (Handler) Preconditions.checkNotNull(handler);
        }

        public void execute(Runnable command) {
            if (Looper.myLooper() == this.mHandler.getLooper()) {
                command.run();
            } else if (!this.mHandler.post((Runnable) Preconditions.checkNotNull(command))) {
                throw new RejectedExecutionException(this.mHandler + " is shutting down");
            }
        }
    }
}
