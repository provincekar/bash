package androidx.core.provider;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import androidx.collection.LruCache;
import androidx.collection.SimpleArrayMap;
import androidx.core.graphics.TypefaceCompat;
import androidx.core.provider.FontsContractCompat;
import androidx.core.util.Consumer;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
class FontRequestWorker {
    static final LruCache sTypefaceCache = new LruCache(16);
    private static final ExecutorService DEFAULT_EXECUTOR_SERVICE = RequestExecutor.createDefaultExecutor("fonts-androidx", 10, 10000);
    static final Object LOCK = new Object();
    static final SimpleArrayMap PENDING_REPLIES = new SimpleArrayMap();

    private FontRequestWorker() {
    }

    static void resetTypefaceCache() {
        sTypefaceCache.evictAll();
    }

    static Typeface requestFontSync(final Context context, final FontRequest request, final CallbackWithHandler callback, final int style, int timeoutInMillis) {
        String createCacheId = createCacheId(request, style);
        Typeface typeface = (Typeface) sTypefaceCache.get(createCacheId);
        if (typeface != null) {
            callback.onTypefaceResult(new TypefaceResult(typeface));
            return typeface;
        }
        if (timeoutInMillis == -1) {
            TypefaceResult fontSync = getFontSync(createCacheId, context, request, style);
            callback.onTypefaceResult(fontSync);
            return fontSync.mTypeface;
        }
        try {
            TypefaceResult typefaceResult = (TypefaceResult) RequestExecutor.submit(DEFAULT_EXECUTOR_SERVICE, new 1(createCacheId, context, request, style), timeoutInMillis);
            callback.onTypefaceResult(typefaceResult);
            return typefaceResult.mTypeface;
        } catch (InterruptedException unused) {
            callback.onTypefaceResult(new TypefaceResult(-3));
            return null;
        }
    }

    class 1 implements Callable {
        final /* synthetic */ Context val$context;
        final /* synthetic */ String val$id;
        final /* synthetic */ FontRequest val$request;
        final /* synthetic */ int val$style;

        1(final String val$id, final Context val$context, final FontRequest val$request, final int val$style) {
            this.val$id = val$id;
            this.val$context = val$context;
            this.val$request = val$request;
            this.val$style = val$style;
        }

        public TypefaceResult call() {
            return FontRequestWorker.getFontSync(this.val$id, this.val$context, this.val$request, this.val$style);
        }
    }

    static Typeface requestFontAsync(final Context context, final FontRequest request, final int style, final Executor executor, final CallbackWithHandler callback) {
        String createCacheId = createCacheId(request, style);
        Typeface typeface = (Typeface) sTypefaceCache.get(createCacheId);
        if (typeface != null) {
            callback.onTypefaceResult(new TypefaceResult(typeface));
            return typeface;
        }
        2 r1 = new 2(callback);
        synchronized (LOCK) {
            SimpleArrayMap simpleArrayMap = PENDING_REPLIES;
            ArrayList arrayList = (ArrayList) simpleArrayMap.get(createCacheId);
            if (arrayList != null) {
                arrayList.add(r1);
                return null;
            }
            ArrayList arrayList2 = new ArrayList();
            arrayList2.add(r1);
            simpleArrayMap.put(createCacheId, arrayList2);
            3 r9 = new 3(createCacheId, context, request, style);
            if (executor == null) {
                executor = DEFAULT_EXECUTOR_SERVICE;
            }
            RequestExecutor.execute(executor, r9, new 4(createCacheId));
            return null;
        }
    }

    class 2 implements Consumer {
        final /* synthetic */ CallbackWithHandler val$callback;

        2(final CallbackWithHandler val$callback) {
            this.val$callback = val$callback;
        }

        public void accept(TypefaceResult typefaceResult) {
            this.val$callback.onTypefaceResult(typefaceResult);
        }
    }

    class 3 implements Callable {
        final /* synthetic */ Context val$context;
        final /* synthetic */ String val$id;
        final /* synthetic */ FontRequest val$request;
        final /* synthetic */ int val$style;

        3(final String val$id, final Context val$context, final FontRequest val$request, final int val$style) {
            this.val$id = val$id;
            this.val$context = val$context;
            this.val$request = val$request;
            this.val$style = val$style;
        }

        public TypefaceResult call() {
            return FontRequestWorker.getFontSync(this.val$id, this.val$context, this.val$request, this.val$style);
        }
    }

    class 4 implements Consumer {
        final /* synthetic */ String val$id;

        4(final String val$id) {
            this.val$id = val$id;
        }

        public void accept(TypefaceResult typefaceResult) {
            synchronized (FontRequestWorker.LOCK) {
                ArrayList arrayList = (ArrayList) FontRequestWorker.PENDING_REPLIES.get(this.val$id);
                if (arrayList == null) {
                    return;
                }
                FontRequestWorker.PENDING_REPLIES.remove(this.val$id);
                for (int r3 = 0; r3 < arrayList.size(); r3++) {
                    ((Consumer) arrayList.get(r3)).accept(typefaceResult);
                }
            }
        }
    }

    private static String createCacheId(FontRequest request, int style) {
        return request.getId() + "-" + style;
    }

    static TypefaceResult getFontSync(final String cacheId, final Context context, final FontRequest request, int style) {
        LruCache lruCache = sTypefaceCache;
        Typeface typeface = (Typeface) lruCache.get(cacheId);
        if (typeface != null) {
            return new TypefaceResult(typeface);
        }
        try {
            FontsContractCompat.FontFamilyResult fontFamilyResult = FontProvider.getFontFamilyResult(context, request, null);
            int fontFamilyResultStatus = getFontFamilyResultStatus(fontFamilyResult);
            if (fontFamilyResultStatus != 0) {
                return new TypefaceResult(fontFamilyResultStatus);
            }
            Typeface createFromFontInfo = TypefaceCompat.createFromFontInfo(context, null, fontFamilyResult.getFonts(), style);
            if (createFromFontInfo != null) {
                lruCache.put(cacheId, createFromFontInfo);
                return new TypefaceResult(createFromFontInfo);
            }
            return new TypefaceResult(-3);
        } catch (PackageManager.NameNotFoundException unused) {
            return new TypefaceResult(-1);
        }
    }

    private static int getFontFamilyResultStatus(FontsContractCompat.FontFamilyResult fontFamilyResult) {
        int r2 = 1;
        if (fontFamilyResult.getStatusCode() != 0) {
            return fontFamilyResult.getStatusCode() != 1 ? -3 : -2;
        }
        FontsContractCompat.FontInfo[] fonts = fontFamilyResult.getFonts();
        if (fonts != null && fonts.length != 0) {
            r2 = 0;
            for (FontsContractCompat.FontInfo fontInfo : fonts) {
                int resultCode = fontInfo.getResultCode();
                if (resultCode != 0) {
                    if (resultCode < 0) {
                        return -3;
                    }
                    return resultCode;
                }
            }
        }
        return r2;
    }

    static final class TypefaceResult {
        final int mResult;
        final Typeface mTypeface;

        TypefaceResult(int result) {
            this.mTypeface = null;
            this.mResult = result;
        }

        TypefaceResult(Typeface typeface) {
            this.mTypeface = typeface;
            this.mResult = 0;
        }

        boolean isSuccess() {
            return this.mResult == 0;
        }
    }
}
