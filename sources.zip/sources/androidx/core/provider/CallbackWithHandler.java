package androidx.core.provider;

import android.graphics.Typeface;
import android.os.Handler;
import androidx.core.provider.FontRequestWorker;
import androidx.core.provider.FontsContractCompat;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
class CallbackWithHandler {
    private final FontsContractCompat.FontRequestCallback mCallback;
    private final Handler mCallbackHandler;

    CallbackWithHandler(FontsContractCompat.FontRequestCallback callback, Handler callbackHandler) {
        this.mCallback = callback;
        this.mCallbackHandler = callbackHandler;
    }

    CallbackWithHandler(FontsContractCompat.FontRequestCallback callback) {
        this.mCallback = callback;
        this.mCallbackHandler = CalleeHandler.create();
    }

    class 1 implements Runnable {
        final /* synthetic */ FontsContractCompat.FontRequestCallback val$callback;
        final /* synthetic */ Typeface val$typeface;

        1(final FontsContractCompat.FontRequestCallback val$callback, final Typeface val$typeface) {
            this.val$callback = val$callback;
            this.val$typeface = val$typeface;
        }

        public void run() {
            this.val$callback.onTypefaceRetrieved(this.val$typeface);
        }
    }

    private void onTypefaceRetrieved(final Typeface typeface) {
        this.mCallbackHandler.post(new 1(this.mCallback, typeface));
    }

    class 2 implements Runnable {
        final /* synthetic */ FontsContractCompat.FontRequestCallback val$callback;
        final /* synthetic */ int val$reason;

        2(final FontsContractCompat.FontRequestCallback val$callback, final int val$reason) {
            this.val$callback = val$callback;
            this.val$reason = val$reason;
        }

        public void run() {
            this.val$callback.onTypefaceRequestFailed(this.val$reason);
        }
    }

    private void onTypefaceRequestFailed(final int reason) {
        this.mCallbackHandler.post(new 2(this.mCallback, reason));
    }

    void onTypefaceResult(FontRequestWorker.TypefaceResult typefaceResult) {
        if (typefaceResult.isSuccess()) {
            onTypefaceRetrieved(typefaceResult.mTypeface);
        } else {
            onTypefaceRequestFailed(typefaceResult.mResult);
        }
    }
}
