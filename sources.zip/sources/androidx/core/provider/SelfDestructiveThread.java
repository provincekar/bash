package androidx.core.provider;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

@Deprecated
/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public class SelfDestructiveThread {
    private static final int MSG_DESTRUCTION = 0;
    private static final int MSG_INVOKE_RUNNABLE = 1;
    private final int mDestructAfterMillisec;
    private Handler mHandler;
    private final int mPriority;
    private HandlerThread mThread;
    private final String mThreadName;
    private final Object mLock = new Object();
    private Handler.Callback mCallback = new 1();
    private int mGeneration = 0;

    public interface ReplyCallback {
        void onReply(Object value);
    }

    class 1 implements Handler.Callback {
        1() {
        }

        public boolean handleMessage(Message msg) {
            int r0 = msg.what;
            if (r0 == 0) {
                SelfDestructiveThread.this.onDestruction();
                return true;
            }
            if (r0 != 1) {
                return true;
            }
            SelfDestructiveThread.this.onInvokeRunnable((Runnable) msg.obj);
            return true;
        }
    }

    public SelfDestructiveThread(String threadName, int priority, int destructAfterMillisec) {
        this.mThreadName = threadName;
        this.mPriority = priority;
        this.mDestructAfterMillisec = destructAfterMillisec;
    }

    public boolean isRunning() {
        boolean z;
        synchronized (this.mLock) {
            z = this.mThread != null;
        }
        return z;
    }

    public int getGeneration() {
        int r1;
        synchronized (this.mLock) {
            r1 = this.mGeneration;
        }
        return r1;
    }

    private void post(Runnable runnable) {
        synchronized (this.mLock) {
            if (this.mThread == null) {
                HandlerThread handlerThread = new HandlerThread(this.mThreadName, this.mPriority);
                this.mThread = handlerThread;
                handlerThread.start();
                this.mHandler = new Handler(this.mThread.getLooper(), this.mCallback);
                this.mGeneration++;
            }
            this.mHandler.removeMessages(0);
            Handler handler = this.mHandler;
            handler.sendMessage(handler.obtainMessage(1, runnable));
        }
    }

    class 2 implements Runnable {
        final /* synthetic */ Callable val$callable;
        final /* synthetic */ Handler val$calleeHandler;
        final /* synthetic */ ReplyCallback val$reply;

        2(final Callable val$callable, final Handler val$calleeHandler, final ReplyCallback val$reply) {
            this.val$callable = val$callable;
            this.val$calleeHandler = val$calleeHandler;
            this.val$reply = val$reply;
        }

        public void run() {
            Object obj;
            try {
                obj = this.val$callable.call();
            } catch (Exception unused) {
                obj = null;
            }
            this.val$calleeHandler.post(new 1(obj));
        }

        class 1 implements Runnable {
            final /* synthetic */ Object val$result;

            1(final Object val$result) {
                this.val$result = val$result;
            }

            public void run() {
                2.this.val$reply.onReply(this.val$result);
            }
        }
    }

    public void postAndReply(final Callable callable, final ReplyCallback reply) {
        post(new 2(callable, CalleeHandler.create(), reply));
    }

    public Object postAndWait(final Callable callable, int timeoutMillis) throws InterruptedException {
        ReentrantLock reentrantLock = new ReentrantLock();
        Condition newCondition = reentrantLock.newCondition();
        AtomicReference atomicReference = new AtomicReference();
        AtomicBoolean atomicBoolean = new AtomicBoolean(true);
        post(new 3(atomicReference, callable, reentrantLock, atomicBoolean, newCondition));
        reentrantLock.lock();
        try {
            if (!atomicBoolean.get()) {
                return atomicReference.get();
            }
            long nanos = TimeUnit.MILLISECONDS.toNanos(timeoutMillis);
            do {
                try {
                    nanos = newCondition.awaitNanos(nanos);
                } catch (InterruptedException unused) {
                }
                if (!atomicBoolean.get()) {
                    return atomicReference.get();
                }
            } while (nanos > 0);
            throw new InterruptedException("timeout");
        } finally {
            reentrantLock.unlock();
        }
    }

    class 3 implements Runnable {
        final /* synthetic */ Callable val$callable;
        final /* synthetic */ Condition val$cond;
        final /* synthetic */ AtomicReference val$holder;
        final /* synthetic */ ReentrantLock val$lock;
        final /* synthetic */ AtomicBoolean val$running;

        3(final AtomicReference val$holder, final Callable val$callable, final ReentrantLock val$lock, final AtomicBoolean val$running, final Condition val$cond) {
            this.val$holder = val$holder;
            this.val$callable = val$callable;
            this.val$lock = val$lock;
            this.val$running = val$running;
            this.val$cond = val$cond;
        }

        public void run() {
            try {
                this.val$holder.set(this.val$callable.call());
            } catch (Exception unused) {
            }
            this.val$lock.lock();
            try {
                this.val$running.set(false);
                this.val$cond.signal();
            } finally {
                this.val$lock.unlock();
            }
        }
    }

    void onInvokeRunnable(Runnable runnable) {
        runnable.run();
        synchronized (this.mLock) {
            this.mHandler.removeMessages(0);
            Handler handler = this.mHandler;
            handler.sendMessageDelayed(handler.obtainMessage(0), this.mDestructAfterMillisec);
        }
    }

    void onDestruction() {
        synchronized (this.mLock) {
            if (this.mHandler.hasMessages(1)) {
                return;
            }
            this.mThread.quit();
            this.mThread = null;
            this.mHandler = null;
        }
    }
}
