package androidx.core.os;

import android.os.Parcel;
import android.os.Parcelable;

@Deprecated
/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final class ParcelableCompat {
    @Deprecated
    public static Parcelable.Creator newCreator(ParcelableCompatCreatorCallbacks callbacks) {
        return new ParcelableCompatCreatorHoneycombMR2(callbacks);
    }

    static class ParcelableCompatCreatorHoneycombMR2 implements Parcelable.ClassLoaderCreator {
        private final ParcelableCompatCreatorCallbacks mCallbacks;

        ParcelableCompatCreatorHoneycombMR2(ParcelableCompatCreatorCallbacks callbacks) {
            this.mCallbacks = callbacks;
        }

        public Object createFromParcel(Parcel in) {
            return this.mCallbacks.createFromParcel(in, null);
        }

        public Object createFromParcel(Parcel in, ClassLoader loader) {
            return this.mCallbacks.createFromParcel(in, loader);
        }

        public Object[] newArray(int size) {
            return this.mCallbacks.newArray(size);
        }
    }

    private ParcelableCompat() {
    }
}
