package androidx.core.text;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public interface TextDirectionHeuristicCompat {
    boolean isRtl(CharSequence cs, int start, int count);

    boolean isRtl(char[] array, int start, int count);
}
