package androidx.core.util;

import java.io.PrintWriter;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final class TimeUtils {
    public static final int HUNDRED_DAY_FIELD_LEN = 19;
    private static final int SECONDS_PER_DAY = 86400;
    private static final int SECONDS_PER_HOUR = 3600;
    private static final int SECONDS_PER_MINUTE = 60;
    private static final Object sFormatSync = new Object();
    private static char[] sFormatStr = new char[24];

    private static int accumField(int amt, int suffix, boolean always, int zeropad) {
        if (amt > 99 || (always && zeropad >= 3)) {
            return suffix + 3;
        }
        if (amt > 9 || (always && zeropad >= 2)) {
            return suffix + 2;
        }
        if (always || amt > 0) {
            return suffix + 1;
        }
        return 0;
    }

    private static int printField(char[] formatStr, int amt, char suffix, int pos, boolean always, int zeropad) {
        int r1;
        if (!always && amt <= 0) {
            return pos;
        }
        if ((!always || zeropad < 3) && amt <= 99) {
            r1 = pos;
        } else {
            int r0 = amt / 100;
            formatStr[pos] = (char) (r0 + 48);
            r1 = pos + 1;
            amt -= r0 * 100;
        }
        if ((always && zeropad >= 2) || amt > 9 || pos != r1) {
            int r5 = amt / 10;
            formatStr[r1] = (char) (r5 + 48);
            r1++;
            amt -= r5 * 10;
        }
        formatStr[r1] = (char) (amt + 48);
        int r12 = r1 + 1;
        formatStr[r12] = suffix;
        return r12 + 1;
    }

    private static int formatDurationLocked(long duration, int fieldLen) {
        char c;
        int r6;
        int r1;
        int r13;
        int r0;
        int r8;
        long j = duration;
        if (sFormatStr.length < fieldLen) {
            sFormatStr = new char[fieldLen];
        }
        char[] cArr = sFormatStr;
        if (j == 0) {
            int r02 = fieldLen - 1;
            while (r02 > 0) {
                cArr[0] = ' ';
            }
            cArr[0] = '0';
            return 1;
        }
        if (j > 0) {
            c = '+';
        } else {
            c = '-';
            j = -j;
        }
        int r12 = (int) (j % 1000);
        int floor = (int) Math.floor(j / 1000);
        if (floor > 86400) {
            r6 = floor / 86400;
            floor -= 86400 * r6;
        } else {
            r6 = 0;
        }
        if (floor > 3600) {
            r1 = floor / 3600;
            floor -= r1 * 3600;
        } else {
            r1 = 0;
        }
        if (floor > 60) {
            int r7 = floor / 60;
            r13 = floor - (r7 * 60);
            r0 = r7;
        } else {
            r13 = floor;
            r0 = 0;
        }
        if (fieldLen != 0) {
            int accumField = accumField(r6, 1, false, 0);
            int accumField2 = accumField + accumField(r1, 1, accumField > 0, 2);
            int accumField3 = accumField2 + accumField(r0, 1, accumField2 > 0, 2);
            int accumField4 = accumField3 + accumField(r13, 1, accumField3 > 0, 2);
            r8 = 0;
            for (int accumField5 = accumField4 + accumField(r12, 2, true, accumField4 > 0 ? 3 : 0) + 1; accumField5 < fieldLen; accumField5++) {
                cArr[r8] = ' ';
                r8++;
            }
        } else {
            r8 = 0;
        }
        cArr[r8] = c;
        int r9 = r8 + 1;
        boolean z = fieldLen != 0;
        int printField = printField(cArr, r6, 'd', r9, false, 0);
        int printField2 = printField(cArr, r1, 'h', printField, printField != r9, z ? 2 : 0);
        int printField3 = printField(cArr, r0, 'm', printField2, printField2 != r9, z ? 2 : 0);
        int printField4 = printField(cArr, r13, 's', printField3, printField3 != r9, z ? 2 : 0);
        int printField5 = printField(cArr, r12, 'm', printField4, true, (!z || printField4 == r9) ? 0 : 3);
        cArr[printField5] = 's';
        return printField5 + 1;
    }

    public static void formatDuration(long duration, StringBuilder builder) {
        synchronized (sFormatSync) {
            builder.append(sFormatStr, 0, formatDurationLocked(duration, 0));
        }
    }

    public static void formatDuration(long duration, PrintWriter pw, int fieldLen) {
        synchronized (sFormatSync) {
            pw.print(new String(sFormatStr, 0, formatDurationLocked(duration, fieldLen)));
        }
    }

    public static void formatDuration(long duration, PrintWriter pw) {
        formatDuration(duration, pw, 0);
    }

    public static void formatDuration(long time, long now, PrintWriter pw) {
        if (time == 0) {
            pw.print("--");
        } else {
            formatDuration(time - now, pw, 0);
        }
    }

    private TimeUtils() {
    }
}
