package androidx.core.util;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final class Pools {

    public interface Pool {
        Object acquire();

        boolean release(Object instance);
    }

    private Pools() {
    }

    public static class SimplePool implements Pool {
        private final Object[] mPool;
        private int mPoolSize;

        public SimplePool(int maxPoolSize) {
            if (maxPoolSize <= 0) {
                throw new IllegalArgumentException("The max pool size must be > 0");
            }
            this.mPool = new Object[maxPoolSize];
        }

        public Object acquire() {
            int r0 = this.mPoolSize;
            if (r0 <= 0) {
                return null;
            }
            int r2 = r0 - 1;
            Object[] objArr = this.mPool;
            Object obj = objArr[r2];
            objArr[r2] = null;
            this.mPoolSize = r0 - 1;
            return obj;
        }

        public boolean release(Object instance) {
            if (isInPool(instance)) {
                throw new IllegalStateException("Already in the pool!");
            }
            int r0 = this.mPoolSize;
            Object[] objArr = this.mPool;
            if (r0 >= objArr.length) {
                return false;
            }
            objArr[r0] = instance;
            this.mPoolSize = r0 + 1;
            return true;
        }

        private boolean isInPool(Object instance) {
            for (int r1 = 0; r1 < this.mPoolSize; r1++) {
                if (this.mPool[r1] == instance) {
                    return true;
                }
            }
            return false;
        }
    }

    public static class SynchronizedPool extends SimplePool {
        private final Object mLock;

        public SynchronizedPool(int maxPoolSize) {
            super(maxPoolSize);
            this.mLock = new Object();
        }

        public Object acquire() {
            Object acquire;
            synchronized (this.mLock) {
                acquire = super.acquire();
            }
            return acquire;
        }

        public boolean release(Object element) {
            boolean release;
            synchronized (this.mLock) {
                release = super.release(element);
            }
            return release;
        }
    }
}
