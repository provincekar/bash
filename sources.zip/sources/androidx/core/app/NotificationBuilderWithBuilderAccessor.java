package androidx.core.app;

import android.app.Notification;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public interface NotificationBuilderWithBuilderAccessor {
    Notification.Builder getBuilder();
}
