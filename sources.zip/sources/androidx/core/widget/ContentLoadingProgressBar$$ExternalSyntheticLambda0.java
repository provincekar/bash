package androidx.core.widget;

/* compiled from: D8$$SyntheticClass */
/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final /* synthetic */ class ContentLoadingProgressBar$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ ContentLoadingProgressBar f$0;

    public /* synthetic */ ContentLoadingProgressBar$$ExternalSyntheticLambda0(ContentLoadingProgressBar contentLoadingProgressBar) {
        this.f$0 = contentLoadingProgressBar;
    }

    public final void run() {
        this.f$0.lambda$new$0$androidx-core-widget-ContentLoadingProgressBar();
    }
}
