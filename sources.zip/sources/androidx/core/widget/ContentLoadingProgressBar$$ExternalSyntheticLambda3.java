package androidx.core.widget;

/* compiled from: D8$$SyntheticClass */
/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final /* synthetic */ class ContentLoadingProgressBar$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ ContentLoadingProgressBar f$0;

    public /* synthetic */ ContentLoadingProgressBar$$ExternalSyntheticLambda3(ContentLoadingProgressBar contentLoadingProgressBar) {
        this.f$0 = contentLoadingProgressBar;
    }

    public final void run() {
        ContentLoadingProgressBar.$r8$lambda$tmknj5M20Tn8TaJxR587u-39ZDQ(this.f$0);
    }
}
