package androidx.core.view;

import android.os.Build;
import android.os.CancellationSignal;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsAnimationControlListener;
import android.view.WindowInsetsAnimationController;
import android.view.WindowInsetsController;
import android.view.animation.Interpolator;
import android.view.inputmethod.InputMethodManager;
import androidx.collection.SimpleArrayMap;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final class WindowInsetsControllerCompat {
    public static final int BEHAVIOR_SHOW_BARS_BY_SWIPE = 1;
    public static final int BEHAVIOR_SHOW_BARS_BY_TOUCH = 0;
    public static final int BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE = 2;
    private final Impl mImpl;

    public interface OnControllableInsetsChangedListener {
        void onControllableInsetsChanged(WindowInsetsControllerCompat controller, int typeMask);
    }

    private WindowInsetsControllerCompat(WindowInsetsController insetsController) {
        if (Build.VERSION.SDK_INT >= 30) {
            this.mImpl = new Impl30(insetsController, this);
        } else {
            this.mImpl = new Impl();
        }
    }

    public WindowInsetsControllerCompat(Window window, View view) {
        if (Build.VERSION.SDK_INT >= 30) {
            this.mImpl = new Impl30(window, this);
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            this.mImpl = new Impl26(window, view);
            return;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            this.mImpl = new Impl23(window, view);
        } else if (Build.VERSION.SDK_INT >= 20) {
            this.mImpl = new Impl20(window, view);
        } else {
            this.mImpl = new Impl();
        }
    }

    public static WindowInsetsControllerCompat toWindowInsetsControllerCompat(WindowInsetsController insetsController) {
        return new WindowInsetsControllerCompat(insetsController);
    }

    public void show(int types) {
        this.mImpl.show(types);
    }

    public void hide(int types) {
        this.mImpl.hide(types);
    }

    public boolean isAppearanceLightStatusBars() {
        return this.mImpl.isAppearanceLightStatusBars();
    }

    public void setAppearanceLightStatusBars(boolean isLight) {
        this.mImpl.setAppearanceLightStatusBars(isLight);
    }

    public boolean isAppearanceLightNavigationBars() {
        return this.mImpl.isAppearanceLightNavigationBars();
    }

    public void setAppearanceLightNavigationBars(boolean isLight) {
        this.mImpl.setAppearanceLightNavigationBars(isLight);
    }

    public void controlWindowInsetsAnimation(int types, long durationMillis, Interpolator interpolator, CancellationSignal cancellationSignal, WindowInsetsAnimationControlListenerCompat listener) {
        this.mImpl.controlWindowInsetsAnimation(types, durationMillis, interpolator, cancellationSignal, listener);
    }

    public void setSystemBarsBehavior(int behavior) {
        this.mImpl.setSystemBarsBehavior(behavior);
    }

    public int getSystemBarsBehavior() {
        return this.mImpl.getSystemBarsBehavior();
    }

    public void addOnControllableInsetsChangedListener(OnControllableInsetsChangedListener listener) {
        this.mImpl.addOnControllableInsetsChangedListener(listener);
    }

    public void removeOnControllableInsetsChangedListener(OnControllableInsetsChangedListener listener) {
        this.mImpl.removeOnControllableInsetsChangedListener(listener);
    }

    private static class Impl {
        void addOnControllableInsetsChangedListener(OnControllableInsetsChangedListener listener) {
        }

        void controlWindowInsetsAnimation(int types, long durationMillis, Interpolator interpolator, CancellationSignal cancellationSignal, WindowInsetsAnimationControlListenerCompat listener) {
        }

        int getSystemBarsBehavior() {
            return 0;
        }

        void hide(int types) {
        }

        public boolean isAppearanceLightNavigationBars() {
            return false;
        }

        public boolean isAppearanceLightStatusBars() {
            return false;
        }

        void removeOnControllableInsetsChangedListener(OnControllableInsetsChangedListener listener) {
        }

        public void setAppearanceLightNavigationBars(boolean isLight) {
        }

        public void setAppearanceLightStatusBars(boolean isLight) {
        }

        void setSystemBarsBehavior(int behavior) {
        }

        void show(int types) {
        }

        Impl() {
        }
    }

    private static class Impl20 extends Impl {
        private final View mView;
        protected final Window mWindow;

        void addOnControllableInsetsChangedListener(OnControllableInsetsChangedListener listener) {
        }

        void controlWindowInsetsAnimation(int types, long durationMillis, Interpolator interpolator, CancellationSignal cancellationSignal, WindowInsetsAnimationControlListenerCompat listener) {
        }

        int getSystemBarsBehavior() {
            return 0;
        }

        void removeOnControllableInsetsChangedListener(OnControllableInsetsChangedListener listener) {
        }

        Impl20(Window window, View view) {
            this.mWindow = window;
            this.mView = view;
        }

        void show(int typeMask) {
            for (int r0 = 1; r0 <= 256; r0 <<= 1) {
                if ((typeMask & r0) != 0) {
                    showForType(r0);
                }
            }
        }

        private void showForType(int type) {
            if (type == 1) {
                unsetSystemUiFlag(4);
                unsetWindowFlag(1024);
                return;
            }
            if (type == 2) {
                unsetSystemUiFlag(2);
                return;
            }
            if (type != 8) {
                return;
            }
            View view = this.mView;
            if (view != null && (view.isInEditMode() || view.onCheckIsTextEditor())) {
                view.requestFocus();
            } else {
                view = this.mWindow.getCurrentFocus();
            }
            if (view == null) {
                view = this.mWindow.findViewById(16908290);
            }
            if (view == null || !view.hasWindowFocus()) {
                return;
            }
            view.post(new 1(view));
        }

        class 1 implements Runnable {
            final /* synthetic */ View val$finalView;

            1(final View val$finalView) {
                this.val$finalView = val$finalView;
            }

            public void run() {
                ((InputMethodManager) this.val$finalView.getContext().getSystemService("input_method")).showSoftInput(this.val$finalView, 0);
            }
        }

        void hide(int typeMask) {
            for (int r0 = 1; r0 <= 256; r0 <<= 1) {
                if ((typeMask & r0) != 0) {
                    hideForType(r0);
                }
            }
        }

        private void hideForType(int type) {
            if (type == 1) {
                setSystemUiFlag(4);
            } else if (type == 2) {
                setSystemUiFlag(2);
            } else {
                if (type != 8) {
                    return;
                }
                ((InputMethodManager) this.mWindow.getContext().getSystemService("input_method")).hideSoftInputFromWindow(this.mWindow.getDecorView().getWindowToken(), 0);
            }
        }

        protected void setSystemUiFlag(int systemUiFlag) {
            View decorView = this.mWindow.getDecorView();
            decorView.setSystemUiVisibility(systemUiFlag | decorView.getSystemUiVisibility());
        }

        protected void unsetSystemUiFlag(int systemUiFlag) {
            View decorView = this.mWindow.getDecorView();
            decorView.setSystemUiVisibility((~systemUiFlag) & decorView.getSystemUiVisibility());
        }

        protected void setWindowFlag(int windowFlag) {
            this.mWindow.addFlags(windowFlag);
        }

        protected void unsetWindowFlag(int windowFlag) {
            this.mWindow.clearFlags(windowFlag);
        }

        void setSystemBarsBehavior(int behavior) {
            if (behavior == 0) {
                unsetSystemUiFlag(6144);
                return;
            }
            if (behavior == 1) {
                unsetSystemUiFlag(4096);
                setSystemUiFlag(2048);
            } else {
                if (behavior != 2) {
                    return;
                }
                unsetSystemUiFlag(2048);
                setSystemUiFlag(4096);
            }
        }
    }

    private static class Impl23 extends Impl20 {
        Impl23(Window window, View view) {
            super(window, view);
        }

        public boolean isAppearanceLightStatusBars() {
            return (this.mWindow.getDecorView().getSystemUiVisibility() & 8192) != 0;
        }

        public void setAppearanceLightStatusBars(boolean isLight) {
            if (isLight) {
                unsetWindowFlag(67108864);
                setWindowFlag(Integer.MIN_VALUE);
                setSystemUiFlag(8192);
                return;
            }
            unsetSystemUiFlag(8192);
        }
    }

    private static class Impl26 extends Impl23 {
        Impl26(Window window, View view) {
            super(window, view);
        }

        public boolean isAppearanceLightNavigationBars() {
            return (this.mWindow.getDecorView().getSystemUiVisibility() & 16) != 0;
        }

        public void setAppearanceLightNavigationBars(boolean isLight) {
            if (isLight) {
                unsetWindowFlag(134217728);
                setWindowFlag(Integer.MIN_VALUE);
                setSystemUiFlag(16);
                return;
            }
            unsetSystemUiFlag(16);
        }
    }

    private static class Impl30 extends Impl {
        final WindowInsetsControllerCompat mCompatController;
        final WindowInsetsController mInsetsController;
        private final SimpleArrayMap mListeners;

        Impl30(Window window, WindowInsetsControllerCompat compatController) {
            this(window.getInsetsController(), compatController);
        }

        Impl30(WindowInsetsController insetsController, WindowInsetsControllerCompat compatController) {
            this.mListeners = new SimpleArrayMap();
            this.mInsetsController = insetsController;
            this.mCompatController = compatController;
        }

        void show(int types) {
            this.mInsetsController.show(types);
        }

        void hide(int types) {
            this.mInsetsController.hide(types);
        }

        public boolean isAppearanceLightStatusBars() {
            return (this.mInsetsController.getSystemBarsAppearance() & 8) != 0;
        }

        public void setAppearanceLightStatusBars(boolean isLight) {
            if (isLight) {
                this.mInsetsController.setSystemBarsAppearance(8, 8);
            } else {
                this.mInsetsController.setSystemBarsAppearance(0, 8);
            }
        }

        public boolean isAppearanceLightNavigationBars() {
            return (this.mInsetsController.getSystemBarsAppearance() & 16) != 0;
        }

        public void setAppearanceLightNavigationBars(boolean isLight) {
            if (isLight) {
                this.mInsetsController.setSystemBarsAppearance(16, 16);
            } else {
                this.mInsetsController.setSystemBarsAppearance(0, 16);
            }
        }

        class 1 implements WindowInsetsAnimationControlListener {
            private WindowInsetsAnimationControllerCompat mCompatAnimController = null;
            final /* synthetic */ WindowInsetsAnimationControlListenerCompat val$listener;

            1(final WindowInsetsAnimationControlListenerCompat val$listener) {
                this.val$listener = val$listener;
            }

            public void onReady(WindowInsetsAnimationController controller, int types) {
                WindowInsetsAnimationControllerCompat windowInsetsAnimationControllerCompat = new WindowInsetsAnimationControllerCompat(controller);
                this.mCompatAnimController = windowInsetsAnimationControllerCompat;
                this.val$listener.onReady(windowInsetsAnimationControllerCompat, types);
            }

            public void onFinished(WindowInsetsAnimationController controller) {
                this.val$listener.onFinished(this.mCompatAnimController);
            }

            public void onCancelled(WindowInsetsAnimationController controller) {
                this.val$listener.onCancelled(controller == null ? null : this.mCompatAnimController);
            }
        }

        void controlWindowInsetsAnimation(int types, long durationMillis, Interpolator interpolator, CancellationSignal cancellationSignal, final WindowInsetsAnimationControlListenerCompat listener) {
            this.mInsetsController.controlWindowInsetsAnimation(types, durationMillis, interpolator, cancellationSignal, new 1(listener));
        }

        void setSystemBarsBehavior(int behavior) {
            this.mInsetsController.setSystemBarsBehavior(behavior);
        }

        int getSystemBarsBehavior() {
            return this.mInsetsController.getSystemBarsBehavior();
        }

        void addOnControllableInsetsChangedListener(final OnControllableInsetsChangedListener listener) {
            if (this.mListeners.containsKey(listener)) {
                return;
            }
            2 r0 = new 2(listener);
            this.mListeners.put(listener, r0);
            this.mInsetsController.addOnControllableInsetsChangedListener(r0);
        }

        class 2 implements WindowInsetsController.OnControllableInsetsChangedListener {
            final /* synthetic */ OnControllableInsetsChangedListener val$listener;

            2(final OnControllableInsetsChangedListener val$listener) {
                this.val$listener = val$listener;
            }

            public void onControllableInsetsChanged(WindowInsetsController controller, int typeMask) {
                if (Impl30.this.mInsetsController == controller) {
                    this.val$listener.onControllableInsetsChanged(Impl30.this.mCompatController, typeMask);
                }
            }
        }

        void removeOnControllableInsetsChangedListener(OnControllableInsetsChangedListener listener) {
            WindowInsetsController.OnControllableInsetsChangedListener onControllableInsetsChangedListener = (WindowInsetsController.OnControllableInsetsChangedListener) this.mListeners.remove(listener);
            if (onControllableInsetsChangedListener != null) {
                this.mInsetsController.removeOnControllableInsetsChangedListener(onControllableInsetsChangedListener);
            }
        }
    }
}
