package androidx.core.view.animation;

import android.graphics.Path;
import android.graphics.PathMeasure;
import android.view.animation.Interpolator;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
class PathInterpolatorApi14 implements Interpolator {
    private static final float PRECISION = 0.002f;
    private final float[] mX;
    private final float[] mY;

    PathInterpolatorApi14(Path path) {
        PathMeasure pathMeasure = new PathMeasure(path, false);
        float length = pathMeasure.getLength();
        int r2 = ((int) (length / 0.002f)) + 1;
        this.mX = new float[r2];
        this.mY = new float[r2];
        float[] fArr = new float[2];
        for (int r5 = 0; r5 < r2; r5++) {
            pathMeasure.getPosTan((r5 * length) / (r2 - 1), fArr, (float[]) null);
            this.mX[r5] = fArr[0];
            this.mY[r5] = fArr[1];
        }
    }

    PathInterpolatorApi14(float controlX, float controlY) {
        this(createQuad(controlX, controlY));
    }

    PathInterpolatorApi14(float controlX1, float controlY1, float controlX2, float controlY2) {
        this(createCubic(controlX1, controlY1, controlX2, controlY2));
    }

    public float getInterpolation(float t) {
        if (t <= 0.0f) {
            return 0.0f;
        }
        if (t >= 1.0f) {
            return 1.0f;
        }
        int r1 = 0;
        int length = this.mX.length - 1;
        while (length - r1 > 1) {
            int r4 = (r1 + length) / 2;
            if (t < this.mX[r4]) {
                length = r4;
            } else {
                r1 = r4;
            }
        }
        float[] fArr = this.mX;
        float f = fArr[length] - fArr[r1];
        if (f == 0.0f) {
            return this.mY[r1];
        }
        float f2 = (t - fArr[r1]) / f;
        float[] fArr2 = this.mY;
        float f3 = fArr2[r1];
        return f3 + (f2 * (fArr2[length] - f3));
    }

    private static Path createQuad(float controlX, float controlY) {
        Path path = new Path();
        path.moveTo(0.0f, 0.0f);
        path.quadTo(controlX, controlY, 1.0f, 1.0f);
        return path;
    }

    private static Path createCubic(float controlX1, float controlY1, float controlX2, float controlY2) {
        Path path = new Path();
        path.moveTo(0.0f, 0.0f);
        path.cubicTo(controlX1, controlY1, controlX2, controlY2, 1.0f, 1.0f);
        return path;
    }
}
