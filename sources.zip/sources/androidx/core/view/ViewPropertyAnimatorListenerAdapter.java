package androidx.core.view;

import android.view.View;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public class ViewPropertyAnimatorListenerAdapter implements ViewPropertyAnimatorListener {
    public void onAnimationCancel(View view) {
    }

    public void onAnimationEnd(View view) {
    }

    public void onAnimationStart(View view) {
    }
}
