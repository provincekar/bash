package androidx.core.content.pm;

@Deprecated
/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final class ActivityInfoCompat {

    @Deprecated
    public static final int CONFIG_UI_MODE = 512;

    private ActivityInfoCompat() {
    }
}
