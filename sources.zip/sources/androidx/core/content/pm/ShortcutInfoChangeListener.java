package androidx.core.content.pm;

import java.util.List;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public abstract class ShortcutInfoChangeListener {
    public void onAllShortcutsRemoved() {
    }

    public void onShortcutAdded(List shortcuts) {
    }

    public void onShortcutRemoved(List shortcutIds) {
    }

    public void onShortcutUpdated(List shortcuts) {
    }

    public void onShortcutUsageReported(List shortcutIds) {
    }
}
