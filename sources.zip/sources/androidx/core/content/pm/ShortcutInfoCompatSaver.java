package androidx.core.content.pm;

import java.util.ArrayList;
import java.util.List;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public abstract class ShortcutInfoCompatSaver {

    public static class NoopImpl extends ShortcutInfoCompatSaver {
        public Void addShortcuts(List shortcuts) {
            return null;
        }

        public Void removeAllShortcuts() {
            return null;
        }

        public Void removeShortcuts(List shortcutIds) {
            return null;
        }
    }

    public abstract Object addShortcuts(List shortcuts);

    public abstract Object removeAllShortcuts();

    public abstract Object removeShortcuts(List shortcutIds);

    public List getShortcuts() throws Exception {
        return new ArrayList();
    }
}
