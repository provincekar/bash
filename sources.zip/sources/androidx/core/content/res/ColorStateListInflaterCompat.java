package androidx.core.content.res;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.util.StateSet;
import android.util.TypedValue;
import android.util.Xml;
import androidx.core.R;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final class ColorStateListInflaterCompat {
    private static final ThreadLocal sTempTypedValue = new ThreadLocal();

    private ColorStateListInflaterCompat() {
    }

    public static ColorStateList inflate(Resources resources, int resId, Resources.Theme theme) {
        try {
            return createFromXml(resources, resources.getXml(resId), theme);
        } catch (Exception e) {
            Log.e("CSLCompat", "Failed to inflate ColorStateList.", e);
            return null;
        }
    }

    public static ColorStateList createFromXml(Resources r, XmlPullParser parser, Resources.Theme theme) throws XmlPullParserException, IOException {
        int next;
        AttributeSet asAttributeSet = Xml.asAttributeSet(parser);
        do {
            next = parser.next();
            if (next == 2) {
                break;
            }
        } while (next != 1);
        if (next != 2) {
            throw new XmlPullParserException("No start tag found");
        }
        return createFromXmlInner(r, parser, asAttributeSet, theme);
    }

    public static ColorStateList createFromXmlInner(Resources r, XmlPullParser parser, AttributeSet attrs, Resources.Theme theme) throws XmlPullParserException, IOException {
        String name = parser.getName();
        if (!name.equals("selector")) {
            throw new XmlPullParserException(parser.getPositionDescription() + ": invalid color state list tag " + name);
        }
        return inflate(r, parser, attrs, theme);
    }

    private static ColorStateList inflate(Resources r, XmlPullParser parser, AttributeSet attrs, Resources.Theme theme) throws XmlPullParserException, IOException {
        int depth;
        int color;
        int r4 = 1;
        int depth2 = parser.getDepth() + 1;
        int[][] r6 = new int[20][];
        int[] r5 = new int[20];
        int r8 = 0;
        while (true) {
            int next = parser.next();
            if (next == r4 || ((depth = parser.getDepth()) < depth2 && next == 3)) {
                break;
            }
            if (next == 2 && depth <= depth2 && parser.getName().equals("item")) {
                TypedArray obtainAttributes = obtainAttributes(r, theme, attrs, R.styleable.ColorStateListItem);
                int resourceId = obtainAttributes.getResourceId(R.styleable.ColorStateListItem_android_color, -1);
                if (resourceId != -1 && !isColorInt(r, resourceId)) {
                    try {
                        color = createFromXml(r, r.getXml(resourceId), theme).getDefaultColor();
                    } catch (Exception unused) {
                        color = obtainAttributes.getColor(R.styleable.ColorStateListItem_android_color, -65281);
                    }
                } else {
                    color = obtainAttributes.getColor(R.styleable.ColorStateListItem_android_color, -65281);
                }
                float f = 1.0f;
                if (obtainAttributes.hasValue(R.styleable.ColorStateListItem_android_alpha)) {
                    f = obtainAttributes.getFloat(R.styleable.ColorStateListItem_android_alpha, 1.0f);
                } else if (obtainAttributes.hasValue(R.styleable.ColorStateListItem_alpha)) {
                    f = obtainAttributes.getFloat(R.styleable.ColorStateListItem_alpha, 1.0f);
                }
                obtainAttributes.recycle();
                int attributeCount = attrs.getAttributeCount();
                int[] r12 = new int[attributeCount];
                int r14 = 0;
                for (int r13 = 0; r13 < attributeCount; r13++) {
                    int attributeNameResource = attrs.getAttributeNameResource(r13);
                    if (attributeNameResource != 16843173 && attributeNameResource != 16843551 && attributeNameResource != R.attr.alpha) {
                        int r42 = r14 + 1;
                        if (!attrs.getAttributeBooleanValue(r13, false)) {
                            attributeNameResource = -attributeNameResource;
                        }
                        r12[r14] = attributeNameResource;
                        r14 = r42;
                    }
                }
                int[] trimStateSet = StateSet.trimStateSet(r12, r14);
                r5 = GrowingArrayUtils.append(r5, r8, modulateColorAlpha(color, f));
                r6 = (int[][]) GrowingArrayUtils.append(r6, r8, trimStateSet);
                r8++;
            }
            r4 = 1;
        }
        int[] r0 = new int[r8];
        int[][] r1 = new int[r8][];
        System.arraycopy(r5, 0, r0, 0, r8);
        System.arraycopy(r6, 0, r1, 0, r8);
        return new ColorStateList(r1, r0);
    }

    private static boolean isColorInt(Resources r, int resId) {
        TypedValue typedValue = getTypedValue();
        r.getValue(resId, typedValue, true);
        return typedValue.type >= 28 && typedValue.type <= 31;
    }

    private static TypedValue getTypedValue() {
        ThreadLocal threadLocal = sTempTypedValue;
        TypedValue typedValue = (TypedValue) threadLocal.get();
        if (typedValue != null) {
            return typedValue;
        }
        TypedValue typedValue2 = new TypedValue();
        threadLocal.set(typedValue2);
        return typedValue2;
    }

    private static TypedArray obtainAttributes(Resources res, Resources.Theme theme, AttributeSet set, int[] attrs) {
        if (theme == null) {
            return res.obtainAttributes(set, attrs);
        }
        return theme.obtainStyledAttributes(set, attrs, 0, 0);
    }

    private static int modulateColorAlpha(int color, float alphaMod) {
        return (color & 16777215) | (Math.round(Color.alpha(color) * alphaMod) << 24);
    }
}
