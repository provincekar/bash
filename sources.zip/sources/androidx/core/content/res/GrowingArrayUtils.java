package androidx.core.content.res;

import java.lang.reflect.Array;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
final class GrowingArrayUtils {
    public static int growSize(int currentSize) {
        if (currentSize <= 4) {
            return 8;
        }
        return currentSize * 2;
    }

    public static Object[] append(Object[] array, int currentSize, Object element) {
        if (currentSize + 1 > array.length) {
            Object[] objArr = (Object[]) Array.newInstance(array.getClass().getComponentType(), growSize(currentSize));
            System.arraycopy(array, 0, objArr, 0, currentSize);
            array = objArr;
        }
        array[currentSize] = element;
        return array;
    }

    public static int[] append(int[] array, int currentSize, int element) {
        if (currentSize + 1 > array.length) {
            int[] r0 = new int[growSize(currentSize)];
            System.arraycopy(array, 0, r0, 0, currentSize);
            array = r0;
        }
        array[currentSize] = element;
        return array;
    }

    public static long[] append(long[] array, int currentSize, long element) {
        if (currentSize + 1 > array.length) {
            long[] jArr = new long[growSize(currentSize)];
            System.arraycopy(array, 0, jArr, 0, currentSize);
            array = jArr;
        }
        array[currentSize] = element;
        return array;
    }

    public static boolean[] append(boolean[] array, int currentSize, boolean element) {
        if (currentSize + 1 > array.length) {
            boolean[] zArr = new boolean[growSize(currentSize)];
            System.arraycopy(array, 0, zArr, 0, currentSize);
            array = zArr;
        }
        array[currentSize] = element;
        return array;
    }

    public static Object[] insert(Object[] array, int currentSize, int index, Object element) {
        if (currentSize + 1 <= array.length) {
            System.arraycopy(array, index, array, index + 1, currentSize - index);
            array[index] = element;
            return array;
        }
        Object[] objArr = (Object[]) Array.newInstance(array.getClass().getComponentType(), growSize(currentSize));
        System.arraycopy(array, 0, objArr, 0, index);
        objArr[index] = element;
        System.arraycopy(array, index, objArr, index + 1, array.length - index);
        return objArr;
    }

    public static int[] insert(int[] array, int currentSize, int index, int element) {
        if (currentSize + 1 <= array.length) {
            System.arraycopy(array, index, array, index + 1, currentSize - index);
            array[index] = element;
            return array;
        }
        int[] r3 = new int[growSize(currentSize)];
        System.arraycopy(array, 0, r3, 0, index);
        r3[index] = element;
        System.arraycopy(array, index, r3, index + 1, array.length - index);
        return r3;
    }

    public static long[] insert(long[] array, int currentSize, int index, long element) {
        if (currentSize + 1 <= array.length) {
            System.arraycopy(array, index, array, index + 1, currentSize - index);
            array[index] = element;
            return array;
        }
        long[] jArr = new long[growSize(currentSize)];
        System.arraycopy(array, 0, jArr, 0, index);
        jArr[index] = element;
        System.arraycopy(array, index, jArr, index + 1, array.length - index);
        return jArr;
    }

    public static boolean[] insert(boolean[] array, int currentSize, int index, boolean element) {
        if (currentSize + 1 <= array.length) {
            System.arraycopy(array, index, array, index + 1, currentSize - index);
            array[index] = element;
            return array;
        }
        boolean[] zArr = new boolean[growSize(currentSize)];
        System.arraycopy(array, 0, zArr, 0, index);
        zArr[index] = element;
        System.arraycopy(array, index, zArr, index + 1, array.length - index);
        return zArr;
    }

    private GrowingArrayUtils() {
    }
}
