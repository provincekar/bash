package androidx.core.internal.view;

import android.view.SubMenu;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public interface SupportSubMenu extends SupportMenu, SubMenu {
}
