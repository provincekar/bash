package androidx.core.net;

import android.net.Uri;
import androidx.core.util.Preconditions;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final class MailTo {
    private static final String BCC = "bcc";
    private static final String BODY = "body";
    private static final String CC = "cc";
    private static final String MAILTO = "mailto";
    public static final String MAILTO_SCHEME = "mailto:";
    private static final String SUBJECT = "subject";
    private static final String TO = "to";
    private HashMap mHeaders = new HashMap();

    private MailTo() {
    }

    public static boolean isMailTo(String uri) {
        return uri != null && uri.startsWith("mailto:");
    }

    public static boolean isMailTo(Uri uri) {
        return uri != null && "mailto".equals(uri.getScheme());
    }

    public static MailTo parse(String uri) throws ParseException {
        String decode;
        String substring;
        Preconditions.checkNotNull(uri);
        if (!isMailTo(uri)) {
            throw new ParseException("Not a mailto scheme");
        }
        int indexOf = uri.indexOf(35);
        if (indexOf != -1) {
            uri = uri.substring(0, indexOf);
        }
        int indexOf2 = uri.indexOf(63);
        if (indexOf2 == -1) {
            decode = Uri.decode(uri.substring(7));
            substring = null;
        } else {
            decode = Uri.decode(uri.substring(7, indexOf2));
            substring = uri.substring(indexOf2 + 1);
        }
        MailTo mailTo = new MailTo();
        if (substring != null) {
            for (String str : substring.split("&")) {
                String[] split = str.split("=", 2);
                if (split.length != 0) {
                    mailTo.mHeaders.put(Uri.decode(split[0]).toLowerCase(Locale.ROOT), split.length > 1 ? Uri.decode(split[1]) : null);
                }
            }
        }
        String to = mailTo.getTo();
        if (to != null) {
            decode = decode + ", " + to;
        }
        mailTo.mHeaders.put("to", decode);
        return mailTo;
    }

    public static MailTo parse(Uri uri) throws ParseException {
        return parse(uri.toString());
    }

    public String getTo() {
        return (String) this.mHeaders.get("to");
    }

    public String getCc() {
        return (String) this.mHeaders.get("cc");
    }

    public String getBcc() {
        return (String) this.mHeaders.get("bcc");
    }

    public String getSubject() {
        return (String) this.mHeaders.get("subject");
    }

    public String getBody() {
        return (String) this.mHeaders.get("body");
    }

    public Map getHeaders() {
        return this.mHeaders;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("mailto:");
        sb.append('?');
        for (Map.Entry entry : this.mHeaders.entrySet()) {
            sb.append(Uri.encode((String) entry.getKey()));
            sb.append('=');
            sb.append(Uri.encode((String) entry.getValue()));
            sb.append('&');
        }
        return sb.toString();
    }
}
