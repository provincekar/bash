package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public interface TintAwareDrawable {
    void setTint(int tint);

    void setTintList(ColorStateList tint);

    void setTintMode(PorterDuff.Mode tintMode);
}
