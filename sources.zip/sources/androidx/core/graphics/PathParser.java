package androidx.core.graphics;

import android.graphics.Path;
import android.util.Log;
import java.util.ArrayList;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public class PathParser {
    private static final String LOGTAG = "PathParser";

    static float[] copyOfRange(float[] original, int start, int end) {
        if (start > end) {
            throw new IllegalArgumentException();
        }
        int length = original.length;
        if (start < 0 || start > length) {
            throw new ArrayIndexOutOfBoundsException();
        }
        int r4 = end - start;
        int min = Math.min(r4, length - start);
        float[] fArr = new float[r4];
        System.arraycopy(original, start, fArr, 0, min);
        return fArr;
    }

    public static Path createPathFromPathData(String pathData) {
        Path path = new Path();
        PathDataNode[] createNodesFromPathData = createNodesFromPathData(pathData);
        if (createNodesFromPathData == null) {
            return null;
        }
        try {
            PathDataNode.nodesToPath(createNodesFromPathData, path);
            return path;
        } catch (RuntimeException e) {
            throw new RuntimeException("Error in parsing " + pathData, e);
        }
    }

    public static PathDataNode[] createNodesFromPathData(String pathData) {
        if (pathData == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        int r3 = 1;
        int r4 = 0;
        while (r3 < pathData.length()) {
            int nextStart = nextStart(pathData, r3);
            String trim = pathData.substring(r4, nextStart).trim();
            if (trim.length() > 0) {
                addNode(arrayList, trim.charAt(0), getFloats(trim));
            }
            r4 = nextStart;
            r3 = nextStart + 1;
        }
        if (r3 - r4 == 1 && r4 < pathData.length()) {
            addNode(arrayList, pathData.charAt(r4), new float[0]);
        }
        return (PathDataNode[]) arrayList.toArray(new PathDataNode[arrayList.size()]);
    }

    public static PathDataNode[] deepCopyNodes(PathDataNode[] source) {
        if (source == null) {
            return null;
        }
        PathDataNode[] pathDataNodeArr = new PathDataNode[source.length];
        for (int r1 = 0; r1 < source.length; r1++) {
            pathDataNodeArr[r1] = new PathDataNode(source[r1]);
        }
        return pathDataNodeArr;
    }

    public static boolean canMorph(PathDataNode[] nodesFrom, PathDataNode[] nodesTo) {
        if (nodesFrom == null || nodesTo == null || nodesFrom.length != nodesTo.length) {
            return false;
        }
        for (int r1 = 0; r1 < nodesFrom.length; r1++) {
            if (nodesFrom[r1].mType != nodesTo[r1].mType || nodesFrom[r1].mParams.length != nodesTo[r1].mParams.length) {
                return false;
            }
        }
        return true;
    }

    public static void updateNodes(PathDataNode[] target, PathDataNode[] source) {
        for (int r1 = 0; r1 < source.length; r1++) {
            target[r1].mType = source[r1].mType;
            for (int r2 = 0; r2 < source[r1].mParams.length; r2++) {
                target[r1].mParams[r2] = source[r1].mParams[r2];
            }
        }
    }

    private static int nextStart(String s, int end) {
        while (end < s.length()) {
            char charAt = s.charAt(end);
            if (((charAt - 'A') * (charAt - 'Z') <= 0 || (charAt - 'a') * (charAt - 'z') <= 0) && charAt != 'e' && charAt != 'E') {
                return end;
            }
            end++;
        }
        return end;
    }

    private static void addNode(ArrayList list, char cmd, float[] val) {
        list.add(new PathDataNode(cmd, val));
    }

    private static class ExtractFloatResult {
        int mEndPosition;
        boolean mEndWithNegOrDot;

        ExtractFloatResult() {
        }
    }

    private static float[] getFloats(String s) {
        if (s.charAt(0) == 'z' || s.charAt(0) == 'Z') {
            return new float[0];
        }
        try {
            float[] fArr = new float[s.length()];
            ExtractFloatResult extractFloatResult = new ExtractFloatResult();
            int length = s.length();
            int r4 = 1;
            int r5 = 0;
            while (r4 < length) {
                extract(s, r4, extractFloatResult);
                int r6 = extractFloatResult.mEndPosition;
                if (r4 < r6) {
                    fArr[r5] = Float.parseFloat(s.substring(r4, r6));
                    r5++;
                }
                r4 = extractFloatResult.mEndWithNegOrDot ? r6 : r6 + 1;
            }
            return copyOfRange(fArr, 0, r5);
        } catch (NumberFormatException e) {
            throw new RuntimeException("error in parsing \"" + s + "\"", e);
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Removed duplicated region for block: B:14:0x003a A[LOOP:0: B:2:0x0007->B:14:0x003a, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:15:0x003d A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0035  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void extract(java.lang.String r8, int r9, androidx.core.graphics.PathParser.ExtractFloatResult r10) {
        /*
            r0 = 0
            r10.mEndWithNegOrDot = r0
            r1 = r9
            r2 = r0
            r3 = r2
            r4 = r3
        L7:
            int r5 = r8.length()
            if (r1 >= r5) goto L3d
            char r5 = r8.charAt(r1)
            r6 = 32
            r7 = 1
            if (r5 == r6) goto L35
            r6 = 69
            if (r5 == r6) goto L33
            r6 = 101(0x65, float:1.42E-43)
            if (r5 == r6) goto L33
            switch(r5) {
                case 44: goto L35;
                case 45: goto L2a;
                case 46: goto L22;
                default: goto L21;
            }
        L21:
            goto L31
        L22:
            if (r3 != 0) goto L27
            r2 = r0
            r3 = r7
            goto L37
        L27:
            r10.mEndWithNegOrDot = r7
            goto L35
        L2a:
            if (r1 == r9) goto L31
            if (r2 != 0) goto L31
            r10.mEndWithNegOrDot = r7
            goto L35
        L31:
            r2 = r0
            goto L37
        L33:
            r2 = r7
            goto L37
        L35:
            r2 = r0
            r4 = r7
        L37:
            if (r4 == 0) goto L3a
            goto L3d
        L3a:
            int r1 = r1 + 1
            goto L7
        L3d:
            r10.mEndPosition = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.PathParser.extract(java.lang.String, int, androidx.core.graphics.PathParser$ExtractFloatResult):void");
    }

    public static boolean interpolatePathDataNodes(PathDataNode[] target, PathDataNode[] from, PathDataNode[] to, float fraction) {
        if (target == null || from == null || to == null) {
            throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes cannot be null");
        }
        if (target.length != from.length || from.length != to.length) {
            throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes must have the same length");
        }
        if (!canMorph(from, to)) {
            return false;
        }
        for (int r1 = 0; r1 < target.length; r1++) {
            target[r1].interpolatePathDataNode(from[r1], to[r1], fraction);
        }
        return true;
    }

    public static class PathDataNode {
        public float[] mParams;
        public char mType;

        PathDataNode(char type, float[] params) {
            this.mType = type;
            this.mParams = params;
        }

        PathDataNode(PathDataNode n) {
            this.mType = n.mType;
            float[] fArr = n.mParams;
            this.mParams = PathParser.copyOfRange(fArr, 0, fArr.length);
        }

        public static void nodesToPath(PathDataNode[] node, Path path) {
            float[] fArr = new float[6];
            char c = 'm';
            for (int r2 = 0; r2 < node.length; r2++) {
                addCommand(path, fArr, c, node[r2].mType, node[r2].mParams);
                c = node[r2].mType;
            }
        }

        public void interpolatePathDataNode(PathDataNode nodeFrom, PathDataNode nodeTo, float fraction) {
            this.mType = nodeFrom.mType;
            int r0 = 0;
            while (true) {
                float[] fArr = nodeFrom.mParams;
                if (r0 >= fArr.length) {
                    return;
                }
                this.mParams[r0] = (fArr[r0] * (1.0f - fraction)) + (nodeTo.mParams[r0] * fraction);
                r0++;
            }
        }

        /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
        private static void addCommand(Path path, float[] fArr, char c, char c2, float[] fArr2) {
            int r6;
            int r19;
            int r24;
            float f;
            float f2;
            float f3;
            float f4;
            float f5;
            float f6;
            float f7;
            float f8;
            char c3 = c2;
            boolean z = false;
            float f9 = fArr[0];
            float f10 = fArr[1];
            float f11 = fArr[2];
            float f12 = fArr[3];
            float f13 = fArr[4];
            float f14 = fArr[5];
            switch (c3) {
                case 'A':
                case 'a':
                    r6 = 7;
                    r19 = r6;
                    break;
                case 'C':
                case 'c':
                    r6 = 6;
                    r19 = r6;
                    break;
                case 'H':
                case 'V':
                case 'h':
                case 'v':
                    r19 = 1;
                    break;
                case 'L':
                case 'M':
                case 'T':
                case 'l':
                case 'm':
                case 't':
                default:
                    r19 = 2;
                    break;
                case 'Q':
                case 'S':
                case 'q':
                case 's':
                    r19 = 4;
                    break;
                case 'Z':
                case 'z':
                    path.close();
                    path.moveTo(f13, f14);
                    f9 = f13;
                    f11 = f9;
                    f10 = f14;
                    f12 = f10;
                    r19 = 2;
                    break;
            }
            float f15 = f9;
            float f16 = f10;
            float f17 = f13;
            float f18 = f14;
            int r7 = 0;
            char c4 = c;
            while (r7 < fArr2.length) {
                if (c3 != 'A') {
                    if (c3 == 'C') {
                        r24 = r7;
                        int r72 = r24 + 2;
                        int r8 = r24 + 3;
                        int r9 = r24 + 4;
                        int r11 = r24 + 5;
                        path.cubicTo(fArr2[r24 + 0], fArr2[r24 + 1], fArr2[r72], fArr2[r8], fArr2[r9], fArr2[r11]);
                        f15 = fArr2[r9];
                        float f19 = fArr2[r11];
                        float f20 = fArr2[r72];
                        float f21 = fArr2[r8];
                        f16 = f19;
                        f12 = f21;
                        f11 = f20;
                    } else if (c3 == 'H') {
                        r24 = r7;
                        int r73 = r24 + 0;
                        path.lineTo(fArr2[r73], f16);
                        f15 = fArr2[r73];
                    } else if (c3 == 'Q') {
                        r24 = r7;
                        int r74 = r24 + 0;
                        int r1 = r24 + 1;
                        int r3 = r24 + 2;
                        int r5 = r24 + 3;
                        path.quadTo(fArr2[r74], fArr2[r1], fArr2[r3], fArr2[r5]);
                        float f22 = fArr2[r74];
                        float f23 = fArr2[r1];
                        f15 = fArr2[r3];
                        f16 = fArr2[r5];
                        f11 = f22;
                        f12 = f23;
                    } else if (c3 == 'V') {
                        r24 = r7;
                        int r75 = r24 + 0;
                        path.lineTo(f15, fArr2[r75]);
                        f16 = fArr2[r75];
                    } else if (c3 != 'a') {
                        if (c3 != 'c') {
                            if (c3 == 'h') {
                                int r0 = r7 + 0;
                                path.rLineTo(fArr2[r0], 0.0f);
                                f15 += fArr2[r0];
                            } else if (c3 != 'q') {
                                if (c3 == 'v') {
                                    int r02 = r7 + 0;
                                    path.rLineTo(0.0f, fArr2[r02]);
                                    f4 = fArr2[r02];
                                } else if (c3 == 'L') {
                                    int r03 = r7 + 0;
                                    int r4 = r7 + 1;
                                    path.lineTo(fArr2[r03], fArr2[r4]);
                                    f15 = fArr2[r03];
                                    f16 = fArr2[r4];
                                } else if (c3 == 'M') {
                                    int r04 = r7 + 0;
                                    f15 = fArr2[r04];
                                    int r12 = r7 + 1;
                                    f16 = fArr2[r12];
                                    if (r7 > 0) {
                                        path.lineTo(fArr2[r04], fArr2[r12]);
                                    } else {
                                        path.moveTo(fArr2[r04], fArr2[r12]);
                                        r24 = r7;
                                        f18 = f16;
                                        f17 = f15;
                                    }
                                } else if (c3 == 'S') {
                                    if (c4 == 'c' || c4 == 's' || c4 == 'C' || c4 == 'S') {
                                        f15 = (f15 * 2.0f) - f11;
                                        f16 = (f16 * 2.0f) - f12;
                                    }
                                    float f24 = f16;
                                    int r82 = r7 + 0;
                                    int r92 = r7 + 1;
                                    int r13 = r7 + 2;
                                    int r14 = r7 + 3;
                                    path.cubicTo(f15, f24, fArr2[r82], fArr2[r92], fArr2[r13], fArr2[r14]);
                                    f = fArr2[r82];
                                    f2 = fArr2[r92];
                                    f15 = fArr2[r13];
                                    f16 = fArr2[r14];
                                    f11 = f;
                                    f12 = f2;
                                } else if (c3 == 'T') {
                                    if (c4 == 'q' || c4 == 't' || c4 == 'Q' || c4 == 'T') {
                                        f15 = (f15 * 2.0f) - f11;
                                        f16 = (f16 * 2.0f) - f12;
                                    }
                                    int r05 = r7 + 0;
                                    int r2 = r7 + 1;
                                    path.quadTo(f15, f16, fArr2[r05], fArr2[r2]);
                                    float f25 = fArr2[r05];
                                    float f26 = fArr2[r2];
                                    r24 = r7;
                                    f12 = f16;
                                    f11 = f15;
                                    f15 = f25;
                                    f16 = f26;
                                } else if (c3 == 'l') {
                                    int r06 = r7 + 0;
                                    int r42 = r7 + 1;
                                    path.rLineTo(fArr2[r06], fArr2[r42]);
                                    f15 += fArr2[r06];
                                    f4 = fArr2[r42];
                                } else if (c3 == 'm') {
                                    int r07 = r7 + 0;
                                    f15 += fArr2[r07];
                                    int r15 = r7 + 1;
                                    f16 += fArr2[r15];
                                    if (r7 > 0) {
                                        path.rLineTo(fArr2[r07], fArr2[r15]);
                                    } else {
                                        path.rMoveTo(fArr2[r07], fArr2[r15]);
                                        r24 = r7;
                                        f18 = f16;
                                        f17 = f15;
                                    }
                                } else if (c3 == 's') {
                                    if (c4 == 'c' || c4 == 's' || c4 == 'C' || c4 == 'S') {
                                        float f27 = f15 - f11;
                                        f5 = f16 - f12;
                                        f6 = f27;
                                    } else {
                                        f6 = 0.0f;
                                        f5 = 0.0f;
                                    }
                                    int r132 = r7 + 0;
                                    int r142 = r7 + 1;
                                    int r152 = r7 + 2;
                                    int r22 = r7 + 3;
                                    path.rCubicTo(f6, f5, fArr2[r132], fArr2[r142], fArr2[r152], fArr2[r22]);
                                    f = fArr2[r132] + f15;
                                    f2 = fArr2[r142] + f16;
                                    f15 += fArr2[r152];
                                    f3 = fArr2[r22];
                                } else if (c3 == 't') {
                                    if (c4 == 'q' || c4 == 't' || c4 == 'Q' || c4 == 'T') {
                                        f7 = f15 - f11;
                                        f8 = f16 - f12;
                                    } else {
                                        f8 = 0.0f;
                                        f7 = 0.0f;
                                    }
                                    int r16 = r7 + 0;
                                    int r32 = r7 + 1;
                                    path.rQuadTo(f7, f8, fArr2[r16], fArr2[r32]);
                                    float f28 = f7 + f15;
                                    float f29 = f8 + f16;
                                    f15 += fArr2[r16];
                                    f16 += fArr2[r32];
                                    f12 = f29;
                                    f11 = f28;
                                }
                                f16 += f4;
                            } else {
                                int r08 = r7 + 0;
                                int r23 = r7 + 1;
                                int r43 = r7 + 2;
                                int r62 = r7 + 3;
                                path.rQuadTo(fArr2[r08], fArr2[r23], fArr2[r43], fArr2[r62]);
                                f = fArr2[r08] + f15;
                                f2 = fArr2[r23] + f16;
                                f15 += fArr2[r43];
                                f3 = fArr2[r62];
                            }
                            r24 = r7;
                        } else {
                            int r133 = r7 + 2;
                            int r143 = r7 + 3;
                            int r153 = r7 + 4;
                            int r222 = r7 + 5;
                            path.rCubicTo(fArr2[r7 + 0], fArr2[r7 + 1], fArr2[r133], fArr2[r143], fArr2[r153], fArr2[r222]);
                            f = fArr2[r133] + f15;
                            f2 = fArr2[r143] + f16;
                            f15 += fArr2[r153];
                            f3 = fArr2[r222];
                        }
                        f16 += f3;
                        f11 = f;
                        f12 = f2;
                        r24 = r7;
                    } else {
                        int r134 = r7 + 5;
                        int r144 = r7 + 6;
                        r24 = r7;
                        drawArc(path, f15, f16, fArr2[r134] + f15, fArr2[r144] + f16, fArr2[r7 + 0], fArr2[r7 + 1], fArr2[r7 + 2], fArr2[r7 + 3] != 0.0f, fArr2[r7 + 4] != 0.0f);
                        f15 += fArr2[r134];
                        f16 += fArr2[r144];
                    }
                    r7 = r24 + r19;
                    c4 = c2;
                    c3 = c4;
                    z = false;
                } else {
                    r24 = r7;
                    int r135 = r24 + 5;
                    int r145 = r24 + 6;
                    drawArc(path, f15, f16, fArr2[r135], fArr2[r145], fArr2[r24 + 0], fArr2[r24 + 1], fArr2[r24 + 2], fArr2[r24 + 3] != 0.0f, fArr2[r24 + 4] != 0.0f);
                    f15 = fArr2[r135];
                    f16 = fArr2[r145];
                }
                f12 = f16;
                f11 = f15;
                r7 = r24 + r19;
                c4 = c2;
                c3 = c4;
                z = false;
            }
            fArr[z ? 1 : 0] = f15;
            fArr[1] = f16;
            fArr[2] = f11;
            fArr[3] = f12;
            fArr[4] = f17;
            fArr[5] = f18;
        }

        private static void drawArc(Path p, float x0, float y0, float x1, float y1, float a, float b, float theta, boolean isMoreThanHalf, boolean isPositiveArc) {
            double d;
            double d2;
            double radians = Math.toRadians(theta);
            double cos = Math.cos(radians);
            double sin = Math.sin(radians);
            double d3 = x0;
            double d4 = d3 * cos;
            double d5 = y0;
            double d6 = a;
            double d7 = (d4 + (d5 * sin)) / d6;
            double d8 = ((-x0) * sin) + (d5 * cos);
            double d9 = b;
            double d10 = d8 / d9;
            double d11 = y1;
            double d12 = ((x1 * cos) + (d11 * sin)) / d6;
            double d13 = (((-x1) * sin) + (d11 * cos)) / d9;
            double d14 = d7 - d12;
            double d15 = d10 - d13;
            double d16 = (d7 + d12) / 2.0d;
            double d17 = (d10 + d13) / 2.0d;
            double d18 = (d14 * d14) + (d15 * d15);
            if (d18 == 0.0d) {
                Log.w("PathParser", " Points are coincident");
                return;
            }
            double d19 = (1.0d / d18) - 0.25d;
            if (d19 < 0.0d) {
                Log.w("PathParser", "Points are too far apart " + d18);
                float sqrt = (float) (Math.sqrt(d18) / 1.99999d);
                drawArc(p, x0, y0, x1, y1, a * sqrt, b * sqrt, theta, isMoreThanHalf, isPositiveArc);
                return;
            }
            double sqrt2 = Math.sqrt(d19);
            double d20 = d14 * sqrt2;
            double d21 = sqrt2 * d15;
            if (isMoreThanHalf == isPositiveArc) {
                d = d16 - d21;
                d2 = d17 + d20;
            } else {
                d = d16 + d21;
                d2 = d17 - d20;
            }
            double atan2 = Math.atan2(d10 - d2, d7 - d);
            double atan22 = Math.atan2(d13 - d2, d12 - d) - atan2;
            if (isPositiveArc != (atan22 >= 0.0d)) {
                atan22 = atan22 > 0.0d ? atan22 - 6.283185307179586d : atan22 + 6.283185307179586d;
            }
            double d22 = d * d6;
            double d23 = d2 * d9;
            arcToBezier(p, (d22 * cos) - (d23 * sin), (d22 * sin) + (d23 * cos), d6, d9, d3, d5, radians, atan2, atan22);
        }

        private static void arcToBezier(Path p, double cx, double cy, double a, double b, double e1x, double e1y, double theta, double start, double sweep) {
            double d = a;
            int ceil = (int) Math.ceil(Math.abs((sweep * 4.0d) / 3.141592653589793d));
            double cos = Math.cos(theta);
            double sin = Math.sin(theta);
            double cos2 = Math.cos(start);
            double sin2 = Math.sin(start);
            double d2 = -d;
            double d3 = d2 * cos;
            double d4 = b * sin;
            double d5 = (d3 * sin2) - (d4 * cos2);
            double d6 = d2 * sin;
            double d7 = b * cos;
            double d8 = (sin2 * d6) + (cos2 * d7);
            double d9 = sweep / ceil;
            double d10 = d8;
            double d11 = d5;
            int r2 = 0;
            double d12 = e1x;
            double d13 = e1y;
            double d14 = start;
            while (r2 < ceil) {
                double d15 = d14 + d9;
                double sin3 = Math.sin(d15);
                double cos3 = Math.cos(d15);
                double d16 = (cx + ((d * cos) * cos3)) - (d4 * sin3);
                double d17 = cy + (d * sin * cos3) + (d7 * sin3);
                double d18 = (d3 * sin3) - (d4 * cos3);
                double d19 = (sin3 * d6) + (cos3 * d7);
                double d20 = d15 - d14;
                double tan = Math.tan(d20 / 2.0d);
                double sin4 = (Math.sin(d20) * (Math.sqrt(((tan * 3.0d) * tan) + 4.0d) - 1.0d)) / 3.0d;
                double d21 = d12 + (d11 * sin4);
                p.rLineTo(0.0f, 0.0f);
                p.cubicTo((float) d21, (float) (d13 + (d10 * sin4)), (float) (d16 - (sin4 * d18)), (float) (d17 - (sin4 * d19)), (float) d16, (float) d17);
                r2++;
                d9 = d9;
                sin = sin;
                d12 = d16;
                d6 = d6;
                cos = cos;
                d14 = d15;
                d10 = d19;
                d11 = d18;
                ceil = ceil;
                d13 = d17;
                d = a;
            }
        }
    }

    private PathParser() {
    }
}
