package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.fonts.FontStyle;
import androidx.core.content.res.FontResourcesParserCompat;
import androidx.core.provider.FontsContractCompat;
import java.io.IOException;
import java.io.InputStream;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public class TypefaceCompatApi29Impl extends TypefaceCompatBaseImpl {
    protected FontsContractCompat.FontInfo findBestInfo(FontsContractCompat.FontInfo[] fonts, int style) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }

    protected Typeface createFromInputStream(Context context, InputStream is) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x001c A[Catch: IOException -> 0x0060, Exception -> 0x008b, PHI: r3
      0x001c: PHI (r3v5 android.graphics.fonts.FontFamily$Builder) = (r3v3 android.graphics.fonts.FontFamily$Builder), (r3v1 android.graphics.fonts.FontFamily$Builder) binds: [B:22:0x0051, B:10:0x001a] A[DONT_GENERATE, DONT_INLINE], TRY_LEAVE, TryCatch #1 {Exception -> 0x008b, blocks: (B:3:0x0005, B:6:0x000c, B:8:0x000e, B:11:0x001c, B:29:0x005f, B:37:0x005c, B:42:0x0066, B:45:0x0071, B:48:0x0076), top: B:2:0x0005 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public android.graphics.Typeface createFromFontInfo(android.content.Context r10, android.os.CancellationSignal r11, androidx.core.provider.FontsContractCompat.FontInfo[] r12, int r13) {
        /*
            r9 = this;
            android.content.ContentResolver r9 = r10.getContentResolver()
            r10 = 0
            int r0 = r12.length     // Catch: java.lang.Exception -> L8b
            r1 = 0
            r3 = r10
            r2 = r1
        L9:
            r4 = 1
            if (r2 >= r0) goto L63
            r5 = r12[r2]     // Catch: java.lang.Exception -> L8b
            android.net.Uri r6 = r5.getUri()     // Catch: java.io.IOException -> L60 java.lang.Exception -> L8b
            java.lang.String r7 = "r"
            android.os.ParcelFileDescriptor r6 = r9.openFileDescriptor(r6, r7, r11)     // Catch: java.io.IOException -> L60 java.lang.Exception -> L8b
            if (r6 != 0) goto L20
            if (r6 == 0) goto L60
        L1c:
            r6.close()     // Catch: java.io.IOException -> L60 java.lang.Exception -> L8b
            goto L60
        L20:
            android.graphics.fonts.Font$Builder r7 = new android.graphics.fonts.Font$Builder     // Catch: java.lang.Throwable -> L54
            r7.<init>(r6)     // Catch: java.lang.Throwable -> L54
            int r8 = r5.getWeight()     // Catch: java.lang.Throwable -> L54
            android.graphics.fonts.Font$Builder r7 = r7.setWeight(r8)     // Catch: java.lang.Throwable -> L54
            boolean r8 = r5.isItalic()     // Catch: java.lang.Throwable -> L54
            if (r8 == 0) goto L34
            goto L35
        L34:
            r4 = r1
        L35:
            android.graphics.fonts.Font$Builder r4 = r7.setSlant(r4)     // Catch: java.lang.Throwable -> L54
            int r5 = r5.getTtcIndex()     // Catch: java.lang.Throwable -> L54
            android.graphics.fonts.Font$Builder r4 = r4.setTtcIndex(r5)     // Catch: java.lang.Throwable -> L54
            android.graphics.fonts.Font r4 = r4.build()     // Catch: java.lang.Throwable -> L54
            if (r3 != 0) goto L4e
            android.graphics.fonts.FontFamily$Builder r5 = new android.graphics.fonts.FontFamily$Builder     // Catch: java.lang.Throwable -> L54
            r5.<init>(r4)     // Catch: java.lang.Throwable -> L54
            r3 = r5
            goto L51
        L4e:
            r3.addFont(r4)     // Catch: java.lang.Throwable -> L54
        L51:
            if (r6 == 0) goto L60
            goto L1c
        L54:
            r4 = move-exception
            if (r6 == 0) goto L5f
            r6.close()     // Catch: java.lang.Throwable -> L5b
            goto L5f
        L5b:
            r5 = move-exception
            r4.addSuppressed(r5)     // Catch: java.io.IOException -> L60 java.lang.Exception -> L8b
        L5f:
            throw r4     // Catch: java.io.IOException -> L60 java.lang.Exception -> L8b
        L60:
            int r2 = r2 + 1
            goto L9
        L63:
            if (r3 != 0) goto L66
            return r10
        L66:
            android.graphics.fonts.FontStyle r9 = new android.graphics.fonts.FontStyle     // Catch: java.lang.Exception -> L8b
            r11 = r13 & 1
            if (r11 == 0) goto L6f
            r11 = 700(0x2bc, float:9.81E-43)
            goto L71
        L6f:
            r11 = 400(0x190, float:5.6E-43)
        L71:
            r12 = r13 & 2
            if (r12 == 0) goto L76
            r1 = r4
        L76:
            r9.<init>(r11, r1)     // Catch: java.lang.Exception -> L8b
            android.graphics.Typeface$CustomFallbackBuilder r11 = new android.graphics.Typeface$CustomFallbackBuilder     // Catch: java.lang.Exception -> L8b
            android.graphics.fonts.FontFamily r12 = r3.build()     // Catch: java.lang.Exception -> L8b
            r11.<init>(r12)     // Catch: java.lang.Exception -> L8b
            android.graphics.Typeface$CustomFallbackBuilder r9 = r11.setStyle(r9)     // Catch: java.lang.Exception -> L8b
            android.graphics.Typeface r9 = r9.build()     // Catch: java.lang.Exception -> L8b
            return r9
        L8b:
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.TypefaceCompatApi29Impl.createFromFontInfo(android.content.Context, android.os.CancellationSignal, androidx.core.provider.FontsContractCompat$FontInfo[], int):android.graphics.Typeface");
    }

    public Typeface createFromFontFamilyFilesResourceEntry(Context context, FontResourcesParserCompat.FontFamilyFilesResourceEntry familyEntry, Resources resources, int style) {
        try {
            FontResourcesParserCompat.FontFileResourceEntry[] entries = familyEntry.getEntries();
            int length = entries.length;
            FontFamily.Builder builder = null;
            int r1 = 0;
            while (true) {
                int r3 = 1;
                if (r1 >= length) {
                    break;
                }
                FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry = entries[r1];
                try {
                    Font.Builder weight = new Font.Builder(resources, fontFileResourceEntry.getResourceId()).setWeight(fontFileResourceEntry.getWeight());
                    if (!fontFileResourceEntry.isItalic()) {
                        r3 = 0;
                    }
                    Font build = weight.setSlant(r3).setTtcIndex(fontFileResourceEntry.getTtcIndex()).setFontVariationSettings(fontFileResourceEntry.getVariationSettings()).build();
                    if (builder == null) {
                        builder = new FontFamily.Builder(build);
                    } else {
                        builder.addFont(build);
                    }
                } catch (IOException unused) {
                }
                r1++;
            }
            if (builder == null) {
                return null;
            }
            return new Typeface.CustomFallbackBuilder(builder.build()).setStyle(new FontStyle((style & 1) != 0 ? 700 : 400, (style & 2) != 0 ? 1 : 0)).build();
        } catch (Exception unused2) {
            return null;
        }
    }

    public Typeface createFromResourcesFontFile(Context context, Resources resources, int id, String path, int style) {
        try {
            Font build = new Font.Builder(resources, id).build();
            return new Typeface.CustomFallbackBuilder(new FontFamily.Builder(build).build()).setStyle(build.getStyle()).build();
        } catch (Exception unused) {
            return null;
        }
    }
}
