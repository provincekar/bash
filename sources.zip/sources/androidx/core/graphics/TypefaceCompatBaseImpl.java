package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.util.Log;
import androidx.core.content.res.FontResourcesParserCompat;
import androidx.core.provider.FontsContractCompat;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
class TypefaceCompatBaseImpl {
    private static final int INVALID_KEY = 0;
    private static final String TAG = "TypefaceCompatBaseImpl";
    private ConcurrentHashMap mFontFamilies = new ConcurrentHashMap();

    private interface StyleExtractor {
        int getWeight(Object t);

        boolean isItalic(Object t);
    }

    TypefaceCompatBaseImpl() {
    }

    private static Object findBestFont(Object[] fonts, int style, StyleExtractor extractor) {
        int r0 = (style & 1) == 0 ? 400 : 700;
        boolean z = (style & 2) != 0;
        Object obj = null;
        int r4 = Integer.MAX_VALUE;
        for (Object obj2 : fonts) {
            int abs = (Math.abs(extractor.getWeight(obj2) - r0) * 2) + (extractor.isItalic(obj2) == z ? 0 : 1);
            if (obj == null || r4 > abs) {
                obj = obj2;
                r4 = abs;
            }
        }
        return obj;
    }

    private static long getUniqueKey(final Typeface typeface) {
        if (typeface == null) {
            return 0L;
        }
        try {
            Field declaredField = Typeface.class.getDeclaredField("native_instance");
            declaredField.setAccessible(true);
            return ((Number) declaredField.get(typeface)).longValue();
        } catch (IllegalAccessException e) {
            Log.e("TypefaceCompatBaseImpl", "Could not retrieve font from family.", e);
            return 0L;
        } catch (NoSuchFieldException e2) {
            Log.e("TypefaceCompatBaseImpl", "Could not retrieve font from family.", e2);
            return 0L;
        }
    }

    class 1 implements StyleExtractor {
        1() {
        }

        public int getWeight(FontsContractCompat.FontInfo info) {
            return info.getWeight();
        }

        public boolean isItalic(FontsContractCompat.FontInfo info) {
            return info.isItalic();
        }
    }

    protected FontsContractCompat.FontInfo findBestInfo(FontsContractCompat.FontInfo[] fonts, int style) {
        return (FontsContractCompat.FontInfo) findBestFont(fonts, style, new 1());
    }

    protected Typeface createFromInputStream(Context context, InputStream is) {
        File tempFile = TypefaceCompatUtil.getTempFile(context);
        if (tempFile == null) {
            return null;
        }
        try {
            if (TypefaceCompatUtil.copyToFile(tempFile, is)) {
                return Typeface.createFromFile(tempFile.getPath());
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            tempFile.delete();
        }
    }

    public Typeface createFromFontInfo(Context context, CancellationSignal cancellationSignal, FontsContractCompat.FontInfo[] fonts, int style) {
        Closeable closeable;
        Closeable closeable2 = null;
        if (fonts.length < 1) {
            return null;
        }
        try {
            closeable = context.getContentResolver().openInputStream(findBestInfo(fonts, style).getUri());
        } catch (IOException unused) {
            closeable = null;
        } catch (Throwable th) {
            th = th;
        }
        try {
            Typeface createFromInputStream = createFromInputStream(context, closeable);
            TypefaceCompatUtil.closeQuietly(closeable);
            return createFromInputStream;
        } catch (IOException unused2) {
            TypefaceCompatUtil.closeQuietly(closeable);
            return null;
        } catch (Throwable th2) {
            th = th2;
            closeable2 = closeable;
            TypefaceCompatUtil.closeQuietly(closeable2);
            throw th;
        }
    }

    class 2 implements StyleExtractor {
        2() {
        }

        public int getWeight(FontResourcesParserCompat.FontFileResourceEntry entry) {
            return entry.getWeight();
        }

        public boolean isItalic(FontResourcesParserCompat.FontFileResourceEntry entry) {
            return entry.isItalic();
        }
    }

    private FontResourcesParserCompat.FontFileResourceEntry findBestEntry(FontResourcesParserCompat.FontFamilyFilesResourceEntry entry, int style) {
        return (FontResourcesParserCompat.FontFileResourceEntry) findBestFont(entry.getEntries(), style, new 2());
    }

    public Typeface createFromFontFamilyFilesResourceEntry(Context context, FontResourcesParserCompat.FontFamilyFilesResourceEntry entry, Resources resources, int style) {
        FontResourcesParserCompat.FontFileResourceEntry findBestEntry = findBestEntry(entry, style);
        if (findBestEntry == null) {
            return null;
        }
        Typeface createFromResourcesFontFile = TypefaceCompat.createFromResourcesFontFile(context, resources, findBestEntry.getResourceId(), findBestEntry.getFileName(), style);
        addFontFamily(createFromResourcesFontFile, entry);
        return createFromResourcesFontFile;
    }

    public Typeface createFromResourcesFontFile(Context context, Resources resources, int id, String path, int style) {
        File tempFile = TypefaceCompatUtil.getTempFile(context);
        if (tempFile == null) {
            return null;
        }
        try {
            if (TypefaceCompatUtil.copyToFile(tempFile, resources, id)) {
                return Typeface.createFromFile(tempFile.getPath());
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            tempFile.delete();
        }
    }

    FontResourcesParserCompat.FontFamilyFilesResourceEntry getFontFamily(final Typeface typeface) {
        long uniqueKey = getUniqueKey(typeface);
        if (uniqueKey == 0) {
            return null;
        }
        return (FontResourcesParserCompat.FontFamilyFilesResourceEntry) this.mFontFamilies.get(Long.valueOf(uniqueKey));
    }

    private void addFontFamily(final Typeface typeface, final FontResourcesParserCompat.FontFamilyFilesResourceEntry entry) {
        long uniqueKey = getUniqueKey(typeface);
        if (uniqueKey != 0) {
            this.mFontFamilies.put(Long.valueOf(uniqueKey), entry);
        }
    }
}
