package androidx.collection;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public class ArrayMap extends SimpleArrayMap implements Map {
    MapCollections mCollections;

    public ArrayMap() {
    }

    public ArrayMap(int r1) {
        super(r1);
    }

    public ArrayMap(SimpleArrayMap simpleArrayMap) {
        super(simpleArrayMap);
    }

    class 1 extends MapCollections {
        1() {
        }

        protected int colGetSize() {
            return ArrayMap.this.mSize;
        }

        protected Object colGetEntry(int r1, int r2) {
            return ArrayMap.this.mArray[(r1 << 1) + r2];
        }

        protected int colIndexOfKey(Object obj) {
            return ArrayMap.this.indexOfKey(obj);
        }

        protected int colIndexOfValue(Object obj) {
            return ArrayMap.this.indexOfValue(obj);
        }

        protected Map colGetMap() {
            return ArrayMap.this;
        }

        protected void colPut(Object obj, Object obj2) {
            ArrayMap.this.put(obj, obj2);
        }

        protected Object colSetValue(int r1, Object obj) {
            return ArrayMap.this.setValueAt(r1, obj);
        }

        protected void colRemoveAt(int r1) {
            ArrayMap.this.removeAt(r1);
        }

        protected void colClear() {
            ArrayMap.this.clear();
        }
    }

    private MapCollections getCollection() {
        if (this.mCollections == null) {
            this.mCollections = new 1();
        }
        return this.mCollections;
    }

    public boolean containsAll(Collection collection) {
        return MapCollections.containsAllHelper(this, collection);
    }

    public void putAll(Map map) {
        ensureCapacity(this.mSize + map.size());
        for (Map.Entry entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    public boolean removeAll(Collection collection) {
        return MapCollections.removeAllHelper(this, collection);
    }

    public boolean retainAll(Collection collection) {
        return MapCollections.retainAllHelper(this, collection);
    }

    public Set entrySet() {
        return getCollection().getEntrySet();
    }

    public Set keySet() {
        return getCollection().getKeySet();
    }

    public Collection values() {
        return getCollection().getValues();
    }
}
