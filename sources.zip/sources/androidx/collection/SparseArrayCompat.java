package androidx.collection;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public class SparseArrayCompat implements Cloneable {
    private static final Object DELETED = new Object();
    private boolean mGarbage;
    private int[] mKeys;
    private int mSize;
    private Object[] mValues;

    public SparseArrayCompat() {
        this(10);
    }

    public SparseArrayCompat(int r2) {
        this.mGarbage = false;
        if (r2 == 0) {
            this.mKeys = ContainerHelpers.EMPTY_INTS;
            this.mValues = ContainerHelpers.EMPTY_OBJECTS;
        } else {
            int idealIntArraySize = ContainerHelpers.idealIntArraySize(r2);
            this.mKeys = new int[idealIntArraySize];
            this.mValues = new Object[idealIntArraySize];
        }
    }

    public SparseArrayCompat clone() {
        try {
            SparseArrayCompat sparseArrayCompat = (SparseArrayCompat) super.clone();
            sparseArrayCompat.mKeys = (int[]) this.mKeys.clone();
            sparseArrayCompat.mValues = (Object[]) this.mValues.clone();
            return sparseArrayCompat;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public Object get(int r2) {
        return get(r2, null);
    }

    public Object get(int r3, Object obj) {
        int binarySearch = ContainerHelpers.binarySearch(this.mKeys, this.mSize, r3);
        if (binarySearch >= 0) {
            Object[] objArr = this.mValues;
            if (objArr[binarySearch] != DELETED) {
                return objArr[binarySearch];
            }
        }
        return obj;
    }

    @Deprecated
    public void delete(int r1) {
        remove(r1);
    }

    public void remove(int r4) {
        int binarySearch = ContainerHelpers.binarySearch(this.mKeys, this.mSize, r4);
        if (binarySearch >= 0) {
            Object[] objArr = this.mValues;
            Object obj = objArr[binarySearch];
            Object obj2 = DELETED;
            if (obj != obj2) {
                objArr[binarySearch] = obj2;
                this.mGarbage = true;
            }
        }
    }

    public boolean remove(int r2, Object obj) {
        int indexOfKey = indexOfKey(r2);
        if (indexOfKey < 0) {
            return false;
        }
        Object valueAt = valueAt(indexOfKey);
        if (obj != valueAt && (obj == null || !obj.equals(valueAt))) {
            return false;
        }
        removeAt(indexOfKey);
        return true;
    }

    public void removeAt(int r4) {
        Object[] objArr = this.mValues;
        Object obj = objArr[r4];
        Object obj2 = DELETED;
        if (obj != obj2) {
            objArr[r4] = obj2;
            this.mGarbage = true;
        }
    }

    public void removeAtRange(int r2, int r3) {
        int min = Math.min(this.mSize, r3 + r2);
        while (r2 < min) {
            removeAt(r2);
            r2++;
        }
    }

    public Object replace(int r2, Object obj) {
        int indexOfKey = indexOfKey(r2);
        if (indexOfKey < 0) {
            return null;
        }
        Object[] objArr = this.mValues;
        Object obj2 = objArr[indexOfKey];
        objArr[indexOfKey] = obj;
        return obj2;
    }

    public boolean replace(int r2, Object obj, Object obj2) {
        int indexOfKey = indexOfKey(r2);
        if (indexOfKey < 0) {
            return false;
        }
        Object obj3 = this.mValues[indexOfKey];
        if (obj3 != obj && (obj == null || !obj.equals(obj3))) {
            return false;
        }
        this.mValues[indexOfKey] = obj2;
        return true;
    }

    private void gc() {
        int r0 = this.mSize;
        int[] r1 = this.mKeys;
        Object[] objArr = this.mValues;
        int r5 = 0;
        for (int r4 = 0; r4 < r0; r4++) {
            Object obj = objArr[r4];
            if (obj != DELETED) {
                if (r4 != r5) {
                    r1[r5] = r1[r4];
                    objArr[r5] = obj;
                    objArr[r4] = null;
                }
                r5++;
            }
        }
        this.mGarbage = false;
        this.mSize = r5;
    }

    public void put(int r7, Object obj) {
        int binarySearch = ContainerHelpers.binarySearch(this.mKeys, this.mSize, r7);
        if (binarySearch >= 0) {
            this.mValues[binarySearch] = obj;
            return;
        }
        int r0 = ~binarySearch;
        int r1 = this.mSize;
        if (r0 < r1) {
            Object[] objArr = this.mValues;
            if (objArr[r0] == DELETED) {
                this.mKeys[r0] = r7;
                objArr[r0] = obj;
                return;
            }
        }
        if (this.mGarbage && r1 >= this.mKeys.length) {
            gc();
            r0 = ~ContainerHelpers.binarySearch(this.mKeys, this.mSize, r7);
        }
        int r12 = this.mSize;
        if (r12 >= this.mKeys.length) {
            int idealIntArraySize = ContainerHelpers.idealIntArraySize(r12 + 1);
            int[] r2 = new int[idealIntArraySize];
            Object[] objArr2 = new Object[idealIntArraySize];
            int[] r3 = this.mKeys;
            System.arraycopy(r3, 0, r2, 0, r3.length);
            Object[] objArr3 = this.mValues;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.mKeys = r2;
            this.mValues = objArr2;
        }
        int r13 = this.mSize;
        if (r13 - r0 != 0) {
            int[] r22 = this.mKeys;
            int r32 = r0 + 1;
            System.arraycopy(r22, r0, r22, r32, r13 - r0);
            Object[] objArr4 = this.mValues;
            System.arraycopy(objArr4, r0, objArr4, r32, this.mSize - r0);
        }
        this.mKeys[r0] = r7;
        this.mValues[r0] = obj;
        this.mSize++;
    }

    public void putAll(SparseArrayCompat sparseArrayCompat) {
        int size = sparseArrayCompat.size();
        for (int r1 = 0; r1 < size; r1++) {
            put(sparseArrayCompat.keyAt(r1), sparseArrayCompat.valueAt(r1));
        }
    }

    public Object putIfAbsent(int r2, Object obj) {
        Object obj2 = get(r2);
        if (obj2 == null) {
            put(r2, obj);
        }
        return obj2;
    }

    public int size() {
        if (this.mGarbage) {
            gc();
        }
        return this.mSize;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public int keyAt(int r2) {
        if (this.mGarbage) {
            gc();
        }
        return this.mKeys[r2];
    }

    public Object valueAt(int r2) {
        if (this.mGarbage) {
            gc();
        }
        return this.mValues[r2];
    }

    public void setValueAt(int r2, Object obj) {
        if (this.mGarbage) {
            gc();
        }
        this.mValues[r2] = obj;
    }

    public int indexOfKey(int r2) {
        if (this.mGarbage) {
            gc();
        }
        return ContainerHelpers.binarySearch(this.mKeys, this.mSize, r2);
    }

    public int indexOfValue(Object obj) {
        if (this.mGarbage) {
            gc();
        }
        for (int r0 = 0; r0 < this.mSize; r0++) {
            if (this.mValues[r0] == obj) {
                return r0;
            }
        }
        return -1;
    }

    public boolean containsKey(int r1) {
        return indexOfKey(r1) >= 0;
    }

    public boolean containsValue(Object obj) {
        return indexOfValue(obj) >= 0;
    }

    public void clear() {
        int r0 = this.mSize;
        Object[] objArr = this.mValues;
        for (int r3 = 0; r3 < r0; r3++) {
            objArr[r3] = null;
        }
        this.mSize = 0;
        this.mGarbage = false;
    }

    public void append(int r7, Object obj) {
        int r0 = this.mSize;
        if (r0 != 0 && r7 <= this.mKeys[r0 - 1]) {
            put(r7, obj);
            return;
        }
        if (this.mGarbage && r0 >= this.mKeys.length) {
            gc();
        }
        int r02 = this.mSize;
        if (r02 >= this.mKeys.length) {
            int idealIntArraySize = ContainerHelpers.idealIntArraySize(r02 + 1);
            int[] r2 = new int[idealIntArraySize];
            Object[] objArr = new Object[idealIntArraySize];
            int[] r3 = this.mKeys;
            System.arraycopy(r3, 0, r2, 0, r3.length);
            Object[] objArr2 = this.mValues;
            System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
            this.mKeys = r2;
            this.mValues = objArr;
        }
        this.mKeys[r02] = r7;
        this.mValues[r02] = obj;
        this.mSize = r02 + 1;
    }

    public String toString() {
        if (size() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.mSize * 28);
        sb.append('{');
        for (int r1 = 0; r1 < this.mSize; r1++) {
            if (r1 > 0) {
                sb.append(", ");
            }
            sb.append(keyAt(r1));
            sb.append('=');
            Object valueAt = valueAt(r1);
            if (valueAt != this) {
                sb.append(valueAt);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
