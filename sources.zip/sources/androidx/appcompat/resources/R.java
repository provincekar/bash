package androidx.appcompat.resources;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public final class R {

    public static final class attr {
        public static final int alpha = 0x7f030029;
        public static final int font = 0x7f03007d;
        public static final int fontProviderAuthority = 0x7f03007f;
        public static final int fontProviderCerts = 0x7f030080;
        public static final int fontProviderFetchStrategy = 0x7f030081;
        public static final int fontProviderFetchTimeout = 0x7f030082;
        public static final int fontProviderPackage = 0x7f030083;
        public static final int fontProviderQuery = 0x7f030084;
        public static final int fontStyle = 0x7f030086;
        public static final int fontVariationSettings = 0x7f030087;
        public static final int fontWeight = 0x7f030088;
        public static final int ttcIndex = 0x7f03010f;

        private attr() {
        }
    }

    public static final class color {
        public static final int notification_action_color_filter = 0x7f050040;
        public static final int notification_icon_bg_color = 0x7f050041;
        public static final int ripple_material_light = 0x7f05004b;
        public static final int secondary_text_default_material_light = 0x7f05004d;

        private color() {
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 0x7f060051;
        public static final int compat_button_inset_vertical_material = 0x7f060052;
        public static final int compat_button_padding_horizontal_material = 0x7f060053;
        public static final int compat_button_padding_vertical_material = 0x7f060054;
        public static final int compat_control_corner_material = 0x7f060055;
        public static final int compat_notification_large_icon_max_height = 0x7f060056;
        public static final int compat_notification_large_icon_max_width = 0x7f060057;
        public static final int notification_action_icon_size = 0x7f060061;
        public static final int notification_action_text_size = 0x7f060062;
        public static final int notification_big_circle_margin = 0x7f060063;
        public static final int notification_content_margin_start = 0x7f060064;
        public static final int notification_large_icon_height = 0x7f060065;
        public static final int notification_large_icon_width = 0x7f060066;
        public static final int notification_main_column_padding_top = 0x7f060067;
        public static final int notification_media_narrow_margin = 0x7f060068;
        public static final int notification_right_icon_size = 0x7f060069;
        public static final int notification_right_side_padding_top = 0x7f06006a;
        public static final int notification_small_icon_background_padding = 0x7f06006b;
        public static final int notification_small_icon_size_as_large = 0x7f06006c;
        public static final int notification_subtext_size = 0x7f06006d;
        public static final int notification_top_pad = 0x7f06006e;
        public static final int notification_top_pad_large_text = 0x7f06006f;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int abc_vector_test = 0x7f07004f;
        public static final int notification_action_background = 0x7f07005a;
        public static final int notification_bg = 0x7f07005b;
        public static final int notification_bg_low = 0x7f07005c;
        public static final int notification_bg_low_normal = 0x7f07005d;
        public static final int notification_bg_low_pressed = 0x7f07005e;
        public static final int notification_bg_normal = 0x7f07005f;
        public static final int notification_bg_normal_pressed = 0x7f070060;
        public static final int notification_icon_background = 0x7f070061;
        public static final int notification_template_icon_bg = 0x7f070062;
        public static final int notification_template_icon_low_bg = 0x7f070063;
        public static final int notification_tile_bg = 0x7f070064;
        public static final int notify_panel_notification_icon_bg = 0x7f070065;

        private drawable() {
        }
    }

    public static final class id {
        public static final int accessibility_action_clickable_span = 0x7f080006;
        public static final int accessibility_custom_action_0 = 0x7f080007;
        public static final int accessibility_custom_action_1 = 0x7f080008;
        public static final int accessibility_custom_action_10 = 0x7f080009;
        public static final int accessibility_custom_action_11 = 0x7f08000a;
        public static final int accessibility_custom_action_12 = 0x7f08000b;
        public static final int accessibility_custom_action_13 = 0x7f08000c;
        public static final int accessibility_custom_action_14 = 0x7f08000d;
        public static final int accessibility_custom_action_15 = 0x7f08000e;
        public static final int accessibility_custom_action_16 = 0x7f08000f;
        public static final int accessibility_custom_action_17 = 0x7f080010;
        public static final int accessibility_custom_action_18 = 0x7f080011;
        public static final int accessibility_custom_action_19 = 0x7f080012;
        public static final int accessibility_custom_action_2 = 0x7f080013;
        public static final int accessibility_custom_action_20 = 0x7f080014;
        public static final int accessibility_custom_action_21 = 0x7f080015;
        public static final int accessibility_custom_action_22 = 0x7f080016;
        public static final int accessibility_custom_action_23 = 0x7f080017;
        public static final int accessibility_custom_action_24 = 0x7f080018;
        public static final int accessibility_custom_action_25 = 0x7f080019;
        public static final int accessibility_custom_action_26 = 0x7f08001a;
        public static final int accessibility_custom_action_27 = 0x7f08001b;
        public static final int accessibility_custom_action_28 = 0x7f08001c;
        public static final int accessibility_custom_action_29 = 0x7f08001d;
        public static final int accessibility_custom_action_3 = 0x7f08001e;
        public static final int accessibility_custom_action_30 = 0x7f08001f;
        public static final int accessibility_custom_action_31 = 0x7f080020;
        public static final int accessibility_custom_action_4 = 0x7f080021;
        public static final int accessibility_custom_action_5 = 0x7f080022;
        public static final int accessibility_custom_action_6 = 0x7f080023;
        public static final int accessibility_custom_action_7 = 0x7f080024;
        public static final int accessibility_custom_action_8 = 0x7f080025;
        public static final int accessibility_custom_action_9 = 0x7f080026;
        public static final int action_container = 0x7f08002e;
        public static final int action_divider = 0x7f080030;
        public static final int action_image = 0x7f080031;
        public static final int action_text = 0x7f080037;
        public static final int actions = 0x7f080038;
        public static final int async = 0x7f08003d;
        public static final int blocking = 0x7f08003f;
        public static final int chronometer = 0x7f080045;
        public static final int dialog_button = 0x7f08004d;
        public static final int forever = 0x7f080053;
        public static final int icon = 0x7f080058;
        public static final int icon_group = 0x7f080059;
        public static final int info = 0x7f08005c;
        public static final int italic = 0x7f08005d;
        public static final int line1 = 0x7f08005e;
        public static final int line3 = 0x7f08005f;
        public static final int normal = 0x7f080067;
        public static final int notification_background = 0x7f080068;
        public static final int notification_main_column = 0x7f080069;
        public static final int notification_main_column_container = 0x7f08006a;
        public static final int right_icon = 0x7f080071;
        public static final int right_side = 0x7f080072;
        public static final int tag_accessibility_actions = 0x7f08008f;
        public static final int tag_accessibility_clickable_spans = 0x7f080090;
        public static final int tag_accessibility_heading = 0x7f080091;
        public static final int tag_accessibility_pane_title = 0x7f080092;
        public static final int tag_screen_reader_focusable = 0x7f080096;
        public static final int tag_transition_group = 0x7f080098;
        public static final int tag_unhandled_key_event_manager = 0x7f080099;
        public static final int tag_unhandled_key_listeners = 0x7f08009a;
        public static final int text = 0x7f08009c;
        public static final int text2 = 0x7f08009d;
        public static final int time = 0x7f0800a0;
        public static final int title = 0x7f0800a1;

        private id() {
        }
    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 0x7f090004;

        private integer() {
        }
    }

    public static final class layout {
        public static final int custom_dialog = 0x7f0b001d;
        public static final int notification_action = 0x7f0b001e;
        public static final int notification_action_tombstone = 0x7f0b001f;
        public static final int notification_template_custom_big = 0x7f0b0020;
        public static final int notification_template_icon_group = 0x7f0b0021;
        public static final int notification_template_part_chronometer = 0x7f0b0022;
        public static final int notification_template_part_time = 0x7f0b0023;

        private layout() {
        }
    }

    public static final class string {
        public static final int status_bar_notification_info_overflow = 0x7f0e001e;

        private string() {
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 0x7f0f00ed;
        public static final int TextAppearance_Compat_Notification_Info = 0x7f0f00ee;
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f0f00ef;
        public static final int TextAppearance_Compat_Notification_Time = 0x7f0f00f0;
        public static final int TextAppearance_Compat_Notification_Title = 0x7f0f00f1;
        public static final int Widget_Compat_NotificationActionContainer = 0x7f0f015d;
        public static final int Widget_Compat_NotificationActionText = 0x7f0f015e;

        private style() {
        }
    }

    public static final class styleable {
        public static final int AnimatedStateListDrawableCompat_android_constantSize = 0x00000003;
        public static final int AnimatedStateListDrawableCompat_android_dither = 0x00000000;
        public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 0x00000004;
        public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 0x00000005;
        public static final int AnimatedStateListDrawableCompat_android_variablePadding = 0x00000002;
        public static final int AnimatedStateListDrawableCompat_android_visible = 0x00000001;
        public static final int AnimatedStateListDrawableItem_android_drawable = 0x00000001;
        public static final int AnimatedStateListDrawableItem_android_id = 0x00000000;
        public static final int AnimatedStateListDrawableTransition_android_drawable = 0x00000000;
        public static final int AnimatedStateListDrawableTransition_android_fromId = 0x00000002;
        public static final int AnimatedStateListDrawableTransition_android_reversible = 0x00000003;
        public static final int AnimatedStateListDrawableTransition_android_toId = 0x00000001;
        public static final int ColorStateListItem_alpha = 0x00000002;
        public static final int ColorStateListItem_android_alpha = 0x00000001;
        public static final int ColorStateListItem_android_color = 0x00000000;
        public static final int FontFamilyFont_android_font = 0x00000000;
        public static final int FontFamilyFont_android_fontStyle = 0x00000002;
        public static final int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static final int FontFamilyFont_android_fontWeight = 0x00000001;
        public static final int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static final int FontFamilyFont_font = 0x00000005;
        public static final int FontFamilyFont_fontStyle = 0x00000006;
        public static final int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static final int FontFamilyFont_fontWeight = 0x00000008;
        public static final int FontFamilyFont_ttcIndex = 0x00000009;
        public static final int FontFamily_fontProviderAuthority = 0x00000000;
        public static final int FontFamily_fontProviderCerts = 0x00000001;
        public static final int FontFamily_fontProviderFetchStrategy = 0x00000002;
        public static final int FontFamily_fontProviderFetchTimeout = 0x00000003;
        public static final int FontFamily_fontProviderPackage = 0x00000004;
        public static final int FontFamily_fontProviderQuery = 0x00000005;
        public static final int FontFamily_fontProviderSystemFontFamily = 0x00000006;
        public static final int GradientColorItem_android_color = 0x00000000;
        public static final int GradientColorItem_android_offset = 0x00000001;
        public static final int GradientColor_android_centerColor = 0x00000007;
        public static final int GradientColor_android_centerX = 0x00000003;
        public static final int GradientColor_android_centerY = 0x00000004;
        public static final int GradientColor_android_endColor = 0x00000001;
        public static final int GradientColor_android_endX = 0x0000000a;
        public static final int GradientColor_android_endY = 0x0000000b;
        public static final int GradientColor_android_gradientRadius = 0x00000005;
        public static final int GradientColor_android_startColor = 0x00000000;
        public static final int GradientColor_android_startX = 0x00000008;
        public static final int GradientColor_android_startY = 0x00000009;
        public static final int GradientColor_android_tileMode = 0x00000006;
        public static final int GradientColor_android_type = 0x00000002;
        public static final int StateListDrawableItem_android_drawable = 0x00000000;
        public static final int StateListDrawable_android_constantSize = 0x00000003;
        public static final int StateListDrawable_android_dither = 0x00000000;
        public static final int StateListDrawable_android_enterFadeDuration = 0x00000004;
        public static final int StateListDrawable_android_exitFadeDuration = 0x00000005;
        public static final int StateListDrawable_android_variablePadding = 0x00000002;
        public static final int StateListDrawable_android_visible = 0x00000001;
        public static final int[] AnimatedStateListDrawableCompat = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
        public static final int[] AnimatedStateListDrawableItem = {16842960, 16843161};
        public static final int[] AnimatedStateListDrawableTransition = {16843161, 16843849, 16843850, 16843851};
        public static final int[] ColorStateListItem = {16843173, 16843551, 2130903081};
        public static final int[] FontFamily = {2130903167, 2130903168, 2130903169, 2130903170, 2130903171, 2130903172, 2130903173};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, 2130903165, 2130903174, 2130903175, 2130903176, 2130903311};
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int[] StateListDrawable = {16843036, 16843156, 16843157, 16843158, 16843532, 16843533};
        public static final int[] StateListDrawableItem = {16843161};

        private styleable() {
        }
    }

    private R() {
    }
}
