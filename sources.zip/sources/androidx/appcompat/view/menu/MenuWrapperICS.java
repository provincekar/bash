package androidx.appcompat.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import androidx.core.internal.view.SupportMenu;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public class MenuWrapperICS extends BaseMenuWrapper implements Menu {
    private final SupportMenu mWrappedObject;

    public MenuWrapperICS(Context context, SupportMenu supportMenu) {
        super(context);
        if (supportMenu == null) {
            throw new IllegalArgumentException("Wrapped Object can not be null.");
        }
        this.mWrappedObject = supportMenu;
    }

    public MenuItem add(CharSequence charSequence) {
        return getMenuItemWrapper(this.mWrappedObject.add(charSequence));
    }

    public MenuItem add(int r2) {
        return getMenuItemWrapper(this.mWrappedObject.add(r2));
    }

    public MenuItem add(int r2, int r3, int r4, CharSequence charSequence) {
        return getMenuItemWrapper(this.mWrappedObject.add(r2, r3, r4, charSequence));
    }

    public MenuItem add(int r2, int r3, int r4, int r5) {
        return getMenuItemWrapper(this.mWrappedObject.add(r2, r3, r4, r5));
    }

    public SubMenu addSubMenu(CharSequence charSequence) {
        return getSubMenuWrapper(this.mWrappedObject.addSubMenu(charSequence));
    }

    public SubMenu addSubMenu(int r2) {
        return getSubMenuWrapper(this.mWrappedObject.addSubMenu(r2));
    }

    public SubMenu addSubMenu(int r2, int r3, int r4, CharSequence charSequence) {
        return getSubMenuWrapper(this.mWrappedObject.addSubMenu(r2, r3, r4, charSequence));
    }

    public SubMenu addSubMenu(int r2, int r3, int r4, int r5) {
        return getSubMenuWrapper(this.mWrappedObject.addSubMenu(r2, r3, r4, r5));
    }

    public int addIntentOptions(int r13, int r14, int r15, ComponentName componentName, Intent[] intentArr, Intent intent, int r19, MenuItem[] menuItemArr) {
        MenuItem[] menuItemArr2 = menuItemArr != null ? new MenuItem[menuItemArr.length] : null;
        int addIntentOptions = this.mWrappedObject.addIntentOptions(r13, r14, r15, componentName, intentArr, intent, r19, menuItemArr2);
        if (menuItemArr2 != null) {
            int length = menuItemArr2.length;
            for (int r4 = 0; r4 < length; r4++) {
                menuItemArr[r4] = getMenuItemWrapper(menuItemArr2[r4]);
            }
        }
        return addIntentOptions;
    }

    public void removeItem(int r1) {
        internalRemoveItem(r1);
        this.mWrappedObject.removeItem(r1);
    }

    public void removeGroup(int r1) {
        internalRemoveGroup(r1);
        this.mWrappedObject.removeGroup(r1);
    }

    public void clear() {
        internalClear();
        this.mWrappedObject.clear();
    }

    public void setGroupCheckable(int r1, boolean z, boolean z2) {
        this.mWrappedObject.setGroupCheckable(r1, z, z2);
    }

    public void setGroupVisible(int r1, boolean z) {
        this.mWrappedObject.setGroupVisible(r1, z);
    }

    public void setGroupEnabled(int r1, boolean z) {
        this.mWrappedObject.setGroupEnabled(r1, z);
    }

    public boolean hasVisibleItems() {
        return this.mWrappedObject.hasVisibleItems();
    }

    public MenuItem findItem(int r2) {
        return getMenuItemWrapper(this.mWrappedObject.findItem(r2));
    }

    public int size() {
        return this.mWrappedObject.size();
    }

    public MenuItem getItem(int r2) {
        return getMenuItemWrapper(this.mWrappedObject.getItem(r2));
    }

    public void close() {
        this.mWrappedObject.close();
    }

    public boolean performShortcut(int r1, KeyEvent keyEvent, int r3) {
        return this.mWrappedObject.performShortcut(r1, keyEvent, r3);
    }

    public boolean isShortcutKey(int r1, KeyEvent keyEvent) {
        return this.mWrappedObject.isShortcutKey(r1, keyEvent);
    }

    public boolean performIdentifierAction(int r1, int r2) {
        return this.mWrappedObject.performIdentifierAction(r1, r2);
    }

    public void setQwertyMode(boolean z) {
        this.mWrappedObject.setQwertyMode(z);
    }
}
