package androidx.appcompat.widget;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.R;
import androidx.appcompat.view.SupportMenuInflater;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.appcompat.view.menu.ShowableListMenu;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public class PopupMenu {
    private final View mAnchor;
    private final Context mContext;
    private View.OnTouchListener mDragListener;
    private final MenuBuilder mMenu;
    OnMenuItemClickListener mMenuItemClickListener;
    OnDismissListener mOnDismissListener;
    final MenuPopupHelper mPopup;

    public interface OnDismissListener {
        void onDismiss(PopupMenu popupMenu);
    }

    public interface OnMenuItemClickListener {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    public PopupMenu(Context context, View view) {
        this(context, view, 0);
    }

    public PopupMenu(Context context, View view, int r9) {
        this(context, view, r9, R.attr.popupMenuStyle, 0);
    }

    public PopupMenu(Context context, View view, int r11, int r12, int r13) {
        this.mContext = context;
        this.mAnchor = view;
        MenuBuilder menuBuilder = new MenuBuilder(context);
        this.mMenu = menuBuilder;
        menuBuilder.setCallback(new 1());
        MenuPopupHelper menuPopupHelper = new MenuPopupHelper(context, menuBuilder, view, false, r12, r13);
        this.mPopup = menuPopupHelper;
        menuPopupHelper.setGravity(r11);
        menuPopupHelper.setOnDismissListener(new 2());
    }

    class 1 implements MenuBuilder.Callback {
        public void onMenuModeChange(MenuBuilder menuBuilder) {
        }

        1() {
        }

        public boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
            if (PopupMenu.this.mMenuItemClickListener != null) {
                return PopupMenu.this.mMenuItemClickListener.onMenuItemClick(menuItem);
            }
            return false;
        }
    }

    class 2 implements PopupWindow.OnDismissListener {
        2() {
        }

        public void onDismiss() {
            if (PopupMenu.this.mOnDismissListener != null) {
                PopupMenu.this.mOnDismissListener.onDismiss(PopupMenu.this);
            }
        }
    }

    public void setGravity(int r1) {
        this.mPopup.setGravity(r1);
    }

    public int getGravity() {
        return this.mPopup.getGravity();
    }

    class 3 extends ForwardingListener {
        3(View view) {
            super(view);
        }

        protected boolean onForwardingStarted() {
            PopupMenu.this.show();
            return true;
        }

        protected boolean onForwardingStopped() {
            PopupMenu.this.dismiss();
            return true;
        }

        public ShowableListMenu getPopup() {
            return PopupMenu.this.mPopup.getPopup();
        }
    }

    public View.OnTouchListener getDragToOpenListener() {
        if (this.mDragListener == null) {
            this.mDragListener = new 3(this.mAnchor);
        }
        return this.mDragListener;
    }

    public Menu getMenu() {
        return this.mMenu;
    }

    public MenuInflater getMenuInflater() {
        return new SupportMenuInflater(this.mContext);
    }

    public void inflate(int r2) {
        getMenuInflater().inflate(r2, this.mMenu);
    }

    public void show() {
        this.mPopup.show();
    }

    public void dismiss() {
        this.mPopup.dismiss();
    }

    public void setOnMenuItemClickListener(OnMenuItemClickListener onMenuItemClickListener) {
        this.mMenuItemClickListener = onMenuItemClickListener;
    }

    public void setOnDismissListener(OnDismissListener onDismissListener) {
        this.mOnDismissListener = onDismissListener;
    }

    ListView getMenuListView() {
        if (this.mPopup.isShowing()) {
            return this.mPopup.getListView();
        }
        return null;
    }
}
