package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.collection.ArrayMap;
import androidx.core.app.SharedElementCallback;
import androidx.core.os.CancellationSignal;
import androidx.core.util.Preconditions;
import androidx.core.view.OneShotPreDrawListener;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.FragmentAnim;
import androidx.fragment.app.SpecialEffectsController;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
class DefaultSpecialEffectsController extends SpecialEffectsController {
    DefaultSpecialEffectsController(ViewGroup viewGroup) {
        super(viewGroup);
    }

    /* JADX WARN: Removed duplicated region for block: B:41:0x0085  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    void executeOperations(java.util.List r11, boolean r12) {
        /*
            r10 = this;
            java.util.Iterator r0 = r11.iterator()
            r1 = 0
            r6 = r1
            r7 = r6
        L7:
            boolean r1 = r0.hasNext()
            r8 = 1
            if (r1 == 0) goto L44
            java.lang.Object r1 = r0.next()
            androidx.fragment.app.SpecialEffectsController$Operation r1 = (androidx.fragment.app.SpecialEffectsController.Operation) r1
            androidx.fragment.app.Fragment r2 = r1.getFragment()
            android.view.View r2 = r2.mView
            androidx.fragment.app.SpecialEffectsController$Operation$State r2 = androidx.fragment.app.SpecialEffectsController.Operation.State.from(r2)
            int[] r3 = androidx.fragment.app.DefaultSpecialEffectsController.10.$SwitchMap$androidx$fragment$app$SpecialEffectsController$Operation$State
            androidx.fragment.app.SpecialEffectsController$Operation$State r4 = r1.getFinalState()
            int r4 = r4.ordinal()
            r3 = r3[r4]
            if (r3 == r8) goto L3c
            r4 = 2
            if (r3 == r4) goto L3c
            r4 = 3
            if (r3 == r4) goto L3c
            r4 = 4
            if (r3 == r4) goto L36
            goto L7
        L36:
            androidx.fragment.app.SpecialEffectsController$Operation$State r3 = androidx.fragment.app.SpecialEffectsController.Operation.State.VISIBLE
            if (r2 == r3) goto L7
            r7 = r1
            goto L7
        L3c:
            androidx.fragment.app.SpecialEffectsController$Operation$State r3 = androidx.fragment.app.SpecialEffectsController.Operation.State.VISIBLE
            if (r2 != r3) goto L7
            if (r6 != 0) goto L7
            r6 = r1
            goto L7
        L44:
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>(r11)
            java.util.Iterator r11 = r11.iterator()
        L57:
            boolean r2 = r11.hasNext()
            if (r2 == 0) goto L95
            java.lang.Object r2 = r11.next()
            androidx.fragment.app.SpecialEffectsController$Operation r2 = (androidx.fragment.app.SpecialEffectsController.Operation) r2
            androidx.core.os.CancellationSignal r4 = new androidx.core.os.CancellationSignal
            r4.<init>()
            r2.markStartedSpecialEffect(r4)
            androidx.fragment.app.DefaultSpecialEffectsController$AnimationInfo r5 = new androidx.fragment.app.DefaultSpecialEffectsController$AnimationInfo
            r5.<init>(r2, r4, r12)
            r0.add(r5)
            androidx.core.os.CancellationSignal r4 = new androidx.core.os.CancellationSignal
            r4.<init>()
            r2.markStartedSpecialEffect(r4)
            androidx.fragment.app.DefaultSpecialEffectsController$TransitionInfo r5 = new androidx.fragment.app.DefaultSpecialEffectsController$TransitionInfo
            r9 = 0
            if (r12 == 0) goto L83
            if (r2 != r6) goto L86
            goto L85
        L83:
            if (r2 != r7) goto L86
        L85:
            r9 = r8
        L86:
            r5.<init>(r2, r4, r12, r9)
            r3.add(r5)
            androidx.fragment.app.DefaultSpecialEffectsController$1 r4 = new androidx.fragment.app.DefaultSpecialEffectsController$1
            r4.<init>(r1, r2)
            r2.addCompletionListener(r4)
            goto L57
        L95:
            r2 = r10
            r4 = r1
            r5 = r12
            java.util.Map r11 = r2.startTransitions(r3, r4, r5, r6, r7)
            java.lang.Boolean r12 = java.lang.Boolean.valueOf(r8)
            boolean r12 = r11.containsValue(r12)
            r10.startAnimations(r0, r1, r12, r11)
            java.util.Iterator r11 = r1.iterator()
        Lab:
            boolean r12 = r11.hasNext()
            if (r12 == 0) goto Lbb
            java.lang.Object r12 = r11.next()
            androidx.fragment.app.SpecialEffectsController$Operation r12 = (androidx.fragment.app.SpecialEffectsController.Operation) r12
            r10.applyContainerChanges(r12)
            goto Lab
        Lbb:
            r1.clear()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.DefaultSpecialEffectsController.executeOperations(java.util.List, boolean):void");
    }

    static /* synthetic */ class 10 {
        static final /* synthetic */ int[] $SwitchMap$androidx$fragment$app$SpecialEffectsController$Operation$State;

        static {
            int[] r0 = new int[SpecialEffectsController.Operation.State.values().length];
            $SwitchMap$androidx$fragment$app$SpecialEffectsController$Operation$State = r0;
            try {
                r0[SpecialEffectsController.Operation.State.GONE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$androidx$fragment$app$SpecialEffectsController$Operation$State[SpecialEffectsController.Operation.State.INVISIBLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$androidx$fragment$app$SpecialEffectsController$Operation$State[SpecialEffectsController.Operation.State.REMOVED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$androidx$fragment$app$SpecialEffectsController$Operation$State[SpecialEffectsController.Operation.State.VISIBLE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    class 1 implements Runnable {
        final /* synthetic */ List val$awaitingContainerChanges;
        final /* synthetic */ SpecialEffectsController.Operation val$operation;

        1(List list, SpecialEffectsController.Operation operation) {
            this.val$awaitingContainerChanges = list;
            this.val$operation = operation;
        }

        public void run() {
            if (this.val$awaitingContainerChanges.contains(this.val$operation)) {
                this.val$awaitingContainerChanges.remove(this.val$operation);
                DefaultSpecialEffectsController.this.applyContainerChanges(this.val$operation);
            }
        }
    }

    private void startAnimations(List list, List list2, boolean z, Map map) {
        ViewGroup container = getContainer();
        Context context = container.getContext();
        ArrayList arrayList = new ArrayList();
        Iterator it = list.iterator();
        boolean z2 = false;
        while (it.hasNext()) {
            AnimationInfo animationInfo = (AnimationInfo) it.next();
            if (animationInfo.isVisibilityUnchanged()) {
                animationInfo.completeSpecialEffect();
            } else {
                FragmentAnim.AnimationOrAnimator animation = animationInfo.getAnimation(context);
                if (animation == null) {
                    animationInfo.completeSpecialEffect();
                } else {
                    Animator animator = animation.animator;
                    if (animator == null) {
                        arrayList.add(animationInfo);
                    } else {
                        SpecialEffectsController.Operation operation = animationInfo.getOperation();
                        Fragment fragment = operation.getFragment();
                        if (Boolean.TRUE.equals(map.get(operation))) {
                            if (FragmentManager.isLoggingEnabled(2)) {
                                Log.v("FragmentManager", "Ignoring Animator set on " + fragment + " as this Fragment was involved in a Transition.");
                            }
                            animationInfo.completeSpecialEffect();
                        } else {
                            boolean z3 = operation.getFinalState() == SpecialEffectsController.Operation.State.GONE;
                            if (z3) {
                                list2.remove(operation);
                            }
                            View view = fragment.mView;
                            container.startViewTransition(view);
                            animator.addListener(new 2(container, view, z3, operation, animationInfo));
                            animator.setTarget(view);
                            animator.start();
                            animationInfo.getSignal().setOnCancelListener(new 3(animator));
                            z2 = true;
                        }
                    }
                }
            }
        }
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            AnimationInfo animationInfo2 = (AnimationInfo) it2.next();
            SpecialEffectsController.Operation operation2 = animationInfo2.getOperation();
            Fragment fragment2 = operation2.getFragment();
            if (z) {
                if (FragmentManager.isLoggingEnabled(2)) {
                    Log.v("FragmentManager", "Ignoring Animation set on " + fragment2 + " as Animations cannot run alongside Transitions.");
                }
                animationInfo2.completeSpecialEffect();
            } else if (z2) {
                if (FragmentManager.isLoggingEnabled(2)) {
                    Log.v("FragmentManager", "Ignoring Animation set on " + fragment2 + " as Animations cannot run alongside Animators.");
                }
                animationInfo2.completeSpecialEffect();
            } else {
                View view2 = fragment2.mView;
                Animation animation2 = (Animation) Preconditions.checkNotNull(((FragmentAnim.AnimationOrAnimator) Preconditions.checkNotNull(animationInfo2.getAnimation(context))).animation);
                if (operation2.getFinalState() != SpecialEffectsController.Operation.State.REMOVED) {
                    view2.startAnimation(animation2);
                    animationInfo2.completeSpecialEffect();
                } else {
                    container.startViewTransition(view2);
                    FragmentAnim.EndViewTransitionAnimation endViewTransitionAnimation = new FragmentAnim.EndViewTransitionAnimation(animation2, container, view2);
                    endViewTransitionAnimation.setAnimationListener(new 4(container, view2, animationInfo2));
                    view2.startAnimation(endViewTransitionAnimation);
                }
                animationInfo2.getSignal().setOnCancelListener(new 5(view2, container, animationInfo2));
            }
        }
    }

    class 2 extends AnimatorListenerAdapter {
        final /* synthetic */ AnimationInfo val$animationInfo;
        final /* synthetic */ ViewGroup val$container;
        final /* synthetic */ boolean val$isHideOperation;
        final /* synthetic */ SpecialEffectsController.Operation val$operation;
        final /* synthetic */ View val$viewToAnimate;

        2(ViewGroup viewGroup, View view, boolean z, SpecialEffectsController.Operation operation, AnimationInfo animationInfo) {
            this.val$container = viewGroup;
            this.val$viewToAnimate = view;
            this.val$isHideOperation = z;
            this.val$operation = operation;
            this.val$animationInfo = animationInfo;
        }

        public void onAnimationEnd(Animator animator) {
            this.val$container.endViewTransition(this.val$viewToAnimate);
            if (this.val$isHideOperation) {
                this.val$operation.getFinalState().applyState(this.val$viewToAnimate);
            }
            this.val$animationInfo.completeSpecialEffect();
        }
    }

    class 3 implements CancellationSignal.OnCancelListener {
        final /* synthetic */ Animator val$animator;

        3(Animator animator) {
            this.val$animator = animator;
        }

        public void onCancel() {
            this.val$animator.end();
        }
    }

    class 4 implements Animation.AnimationListener {
        final /* synthetic */ AnimationInfo val$animationInfo;
        final /* synthetic */ ViewGroup val$container;
        final /* synthetic */ View val$viewToAnimate;

        public void onAnimationRepeat(Animation animation) {
        }

        public void onAnimationStart(Animation animation) {
        }

        4(ViewGroup viewGroup, View view, AnimationInfo animationInfo) {
            this.val$container = viewGroup;
            this.val$viewToAnimate = view;
            this.val$animationInfo = animationInfo;
        }

        class 1 implements Runnable {
            1() {
            }

            public void run() {
                4.this.val$container.endViewTransition(4.this.val$viewToAnimate);
                4.this.val$animationInfo.completeSpecialEffect();
            }
        }

        public void onAnimationEnd(Animation animation) {
            this.val$container.post(new 1());
        }
    }

    class 5 implements CancellationSignal.OnCancelListener {
        final /* synthetic */ AnimationInfo val$animationInfo;
        final /* synthetic */ ViewGroup val$container;
        final /* synthetic */ View val$viewToAnimate;

        5(View view, ViewGroup viewGroup, AnimationInfo animationInfo) {
            this.val$viewToAnimate = view;
            this.val$container = viewGroup;
            this.val$animationInfo = animationInfo;
        }

        public void onCancel() {
            this.val$viewToAnimate.clearAnimation();
            this.val$container.endViewTransition(this.val$viewToAnimate);
            this.val$animationInfo.completeSpecialEffect();
        }
    }

    private Map startTransitions(List list, List list2, boolean z, SpecialEffectsController.Operation operation, SpecialEffectsController.Operation operation2) {
        View view;
        Object obj;
        ArrayList arrayList;
        Object obj2;
        ArrayList arrayList2;
        Map map;
        SpecialEffectsController.Operation operation3;
        View view2;
        ArrayMap arrayMap;
        SpecialEffectsController.Operation operation4;
        View view3;
        boolean z2;
        FragmentTransitionImpl fragmentTransitionImpl;
        Map map2;
        SpecialEffectsController.Operation operation5;
        ArrayList arrayList3;
        Rect rect;
        SharedElementCallback enterTransitionCallback;
        SharedElementCallback exitTransitionCallback;
        Collection collection;
        Rect rect2;
        boolean z3;
        String findKeyForValue;
        Collection collection2;
        boolean z4 = z;
        SpecialEffectsController.Operation operation6 = operation;
        SpecialEffectsController.Operation operation7 = operation2;
        Map hashMap = new HashMap();
        Iterator it = list.iterator();
        FragmentTransitionImpl fragmentTransitionImpl2 = null;
        while (it.hasNext()) {
            TransitionInfo transitionInfo = (TransitionInfo) it.next();
            if (!transitionInfo.isVisibilityUnchanged()) {
                FragmentTransitionImpl handlingImpl = transitionInfo.getHandlingImpl();
                if (fragmentTransitionImpl2 == null) {
                    fragmentTransitionImpl2 = handlingImpl;
                } else if (handlingImpl != null && fragmentTransitionImpl2 != handlingImpl) {
                    throw new IllegalArgumentException("Mixing framework transitions and AndroidX transitions is not allowed. Fragment " + transitionInfo.getOperation().getFragment() + " returned Transition " + transitionInfo.getTransition() + " which uses a different Transition  type than other Fragments.");
                }
            }
        }
        boolean z5 = false;
        if (fragmentTransitionImpl2 == null) {
            Iterator it2 = list.iterator();
            while (it2.hasNext()) {
                TransitionInfo transitionInfo2 = (TransitionInfo) it2.next();
                hashMap.put(transitionInfo2.getOperation(), false);
                transitionInfo2.completeSpecialEffect();
            }
            return hashMap;
        }
        View view4 = new View(getContainer().getContext());
        Rect rect3 = new Rect();
        ArrayList arrayList4 = new ArrayList();
        ArrayList arrayList5 = new ArrayList();
        ArrayMap arrayMap2 = new ArrayMap();
        Iterator it3 = list.iterator();
        boolean z6 = false;
        Object obj3 = null;
        View view5 = null;
        while (it3.hasNext()) {
            TransitionInfo transitionInfo3 = (TransitionInfo) it3.next();
            if (!transitionInfo3.hasSharedElementTransition() || operation6 == null || operation7 == null) {
                arrayMap = arrayMap2;
                operation4 = operation7;
                view3 = view4;
                z2 = z5;
                fragmentTransitionImpl = fragmentTransitionImpl2;
                map2 = hashMap;
                operation5 = operation6;
                arrayList3 = arrayList5;
                rect = rect3;
                view5 = view5;
            } else {
                Object wrapTransitionInSet = fragmentTransitionImpl2.wrapTransitionInSet(fragmentTransitionImpl2.cloneTransition(transitionInfo3.getSharedElementTransition()));
                Collection sharedElementSourceNames = operation2.getFragment().getSharedElementSourceNames();
                ArrayList sharedElementSourceNames2 = operation.getFragment().getSharedElementSourceNames();
                ArrayList sharedElementTargetNames = operation.getFragment().getSharedElementTargetNames();
                View view6 = view5;
                int r1 = 0;
                while (r1 < sharedElementTargetNames.size()) {
                    int indexOf = sharedElementSourceNames.indexOf(sharedElementTargetNames.get(r1));
                    ArrayList arrayList6 = sharedElementTargetNames;
                    if (indexOf != -1) {
                        sharedElementSourceNames.set(indexOf, sharedElementSourceNames2.get(r1));
                    }
                    r1++;
                    sharedElementTargetNames = arrayList6;
                }
                Collection sharedElementTargetNames2 = operation2.getFragment().getSharedElementTargetNames();
                if (!z4) {
                    enterTransitionCallback = operation.getFragment().getExitTransitionCallback();
                    exitTransitionCallback = operation2.getFragment().getEnterTransitionCallback();
                } else {
                    enterTransitionCallback = operation.getFragment().getEnterTransitionCallback();
                    exitTransitionCallback = operation2.getFragment().getExitTransitionCallback();
                }
                int r9 = 0;
                for (int size = sharedElementSourceNames.size(); r9 < size; size = size) {
                    arrayMap2.put((String) sharedElementSourceNames.get(r9), (String) sharedElementTargetNames2.get(r9));
                    r9++;
                }
                ArrayMap arrayMap3 = new ArrayMap();
                findNamedViews(arrayMap3, operation.getFragment().mView);
                arrayMap3.retainAll(sharedElementSourceNames);
                if (enterTransitionCallback != null) {
                    enterTransitionCallback.onMapSharedElements(sharedElementSourceNames, arrayMap3);
                    int size2 = sharedElementSourceNames.size() - 1;
                    while (size2 >= 0) {
                        String str = (String) sharedElementSourceNames.get(size2);
                        View view7 = (View) arrayMap3.get(str);
                        if (view7 == null) {
                            arrayMap2.remove(str);
                            collection2 = sharedElementSourceNames;
                        } else {
                            collection2 = sharedElementSourceNames;
                            if (!str.equals(ViewCompat.getTransitionName(view7))) {
                                arrayMap2.put(ViewCompat.getTransitionName(view7), (String) arrayMap2.remove(str));
                            }
                        }
                        size2--;
                        sharedElementSourceNames = collection2;
                    }
                    collection = sharedElementSourceNames;
                } else {
                    collection = sharedElementSourceNames;
                    arrayMap2.retainAll(arrayMap3.keySet());
                }
                ArrayMap arrayMap4 = new ArrayMap();
                findNamedViews(arrayMap4, operation2.getFragment().mView);
                arrayMap4.retainAll(sharedElementTargetNames2);
                arrayMap4.retainAll(arrayMap2.values());
                if (exitTransitionCallback != null) {
                    exitTransitionCallback.onMapSharedElements(sharedElementTargetNames2, arrayMap4);
                    for (int size3 = sharedElementTargetNames2.size() - 1; size3 >= 0; size3--) {
                        String str2 = (String) sharedElementTargetNames2.get(size3);
                        View view8 = (View) arrayMap4.get(str2);
                        if (view8 == null) {
                            String findKeyForValue2 = FragmentTransition.findKeyForValue(arrayMap2, str2);
                            if (findKeyForValue2 != null) {
                                arrayMap2.remove(findKeyForValue2);
                            }
                        } else if (!str2.equals(ViewCompat.getTransitionName(view8)) && (findKeyForValue = FragmentTransition.findKeyForValue(arrayMap2, str2)) != null) {
                            arrayMap2.put(findKeyForValue, ViewCompat.getTransitionName(view8));
                        }
                    }
                } else {
                    FragmentTransition.retainValues(arrayMap2, arrayMap4);
                }
                retainMatchingViews(arrayMap3, arrayMap2.keySet());
                retainMatchingViews(arrayMap4, arrayMap2.values());
                if (arrayMap2.isEmpty()) {
                    arrayList4.clear();
                    arrayList5.clear();
                    arrayMap = arrayMap2;
                    arrayList3 = arrayList5;
                    rect = rect3;
                    view3 = view4;
                    fragmentTransitionImpl = fragmentTransitionImpl2;
                    view5 = view6;
                    obj3 = null;
                    z2 = false;
                    operation4 = operation2;
                    map2 = hashMap;
                    operation5 = operation;
                } else {
                    FragmentTransition.callSharedElementStartEnd(operation2.getFragment(), operation.getFragment(), z4, arrayMap3, true);
                    Map map3 = hashMap;
                    arrayMap = arrayMap2;
                    View view9 = view4;
                    ArrayList arrayList7 = arrayList5;
                    Rect rect4 = rect3;
                    ArrayList arrayList8 = arrayList4;
                    OneShotPreDrawListener.add(getContainer(), new 6(operation2, operation, z, arrayMap4));
                    Iterator it4 = arrayMap3.values().iterator();
                    while (it4.hasNext()) {
                        captureTransitioningViews(arrayList8, (View) it4.next());
                    }
                    if (collection.isEmpty()) {
                        view5 = view6;
                    } else {
                        View view10 = (View) arrayMap3.get((String) collection.get(0));
                        fragmentTransitionImpl2.setEpicenter(wrapTransitionInSet, view10);
                        view5 = view10;
                    }
                    Iterator it5 = arrayMap4.values().iterator();
                    while (it5.hasNext()) {
                        captureTransitioningViews(arrayList7, (View) it5.next());
                    }
                    if (sharedElementTargetNames2.isEmpty()) {
                        rect2 = rect4;
                        z3 = false;
                    } else {
                        z3 = false;
                        View view11 = (View) arrayMap4.get((String) sharedElementTargetNames2.get(0));
                        if (view11 != null) {
                            rect2 = rect4;
                            OneShotPreDrawListener.add(getContainer(), new 7(fragmentTransitionImpl2, view11, rect2));
                            view3 = view9;
                            z6 = true;
                            fragmentTransitionImpl2.setSharedElementTargets(wrapTransitionInSet, view3, arrayList8);
                            rect = rect2;
                            arrayList4 = arrayList8;
                            arrayList3 = arrayList7;
                            z2 = z3;
                            fragmentTransitionImpl = fragmentTransitionImpl2;
                            fragmentTransitionImpl2.scheduleRemoveTargets(wrapTransitionInSet, null, null, null, null, wrapTransitionInSet, arrayList3);
                            operation5 = operation;
                            map2 = map3;
                            map2.put(operation5, true);
                            operation4 = operation2;
                            map2.put(operation4, true);
                            obj3 = wrapTransitionInSet;
                        } else {
                            rect2 = rect4;
                        }
                    }
                    view3 = view9;
                    fragmentTransitionImpl2.setSharedElementTargets(wrapTransitionInSet, view3, arrayList8);
                    rect = rect2;
                    arrayList4 = arrayList8;
                    arrayList3 = arrayList7;
                    z2 = z3;
                    fragmentTransitionImpl = fragmentTransitionImpl2;
                    fragmentTransitionImpl2.scheduleRemoveTargets(wrapTransitionInSet, null, null, null, null, wrapTransitionInSet, arrayList3);
                    operation5 = operation;
                    map2 = map3;
                    map2.put(operation5, true);
                    operation4 = operation2;
                    map2.put(operation4, true);
                    obj3 = wrapTransitionInSet;
                }
            }
            z4 = z;
            view4 = view3;
            rect3 = rect;
            arrayList5 = arrayList3;
            z5 = z2;
            operation6 = operation5;
            hashMap = map2;
            operation7 = operation4;
            fragmentTransitionImpl2 = fragmentTransitionImpl;
            arrayMap2 = arrayMap;
        }
        View view12 = view5;
        ArrayMap arrayMap5 = arrayMap2;
        SpecialEffectsController.Operation operation8 = operation7;
        View view13 = view4;
        boolean z7 = z5;
        FragmentTransitionImpl fragmentTransitionImpl3 = fragmentTransitionImpl2;
        Map map4 = hashMap;
        SpecialEffectsController.Operation operation9 = operation6;
        ArrayList arrayList9 = arrayList5;
        Rect rect5 = rect3;
        ArrayList arrayList10 = new ArrayList();
        Iterator it6 = list.iterator();
        Object obj4 = null;
        Object obj5 = null;
        while (it6.hasNext()) {
            TransitionInfo transitionInfo4 = (TransitionInfo) it6.next();
            if (transitionInfo4.isVisibilityUnchanged()) {
                map4.put(transitionInfo4.getOperation(), Boolean.valueOf(z7));
                transitionInfo4.completeSpecialEffect();
                it6 = it6;
            } else {
                Iterator it7 = it6;
                Object cloneTransition = fragmentTransitionImpl3.cloneTransition(transitionInfo4.getTransition());
                SpecialEffectsController.Operation operation10 = transitionInfo4.getOperation();
                boolean z8 = (obj3 == null || !(operation10 == operation9 || operation10 == operation8)) ? z7 : true;
                if (cloneTransition == null) {
                    if (!z8) {
                        map4.put(operation10, Boolean.valueOf(z7));
                        transitionInfo4.completeSpecialEffect();
                    }
                    view = view13;
                    arrayList = arrayList4;
                    arrayList2 = arrayList9;
                    obj = obj4;
                    obj2 = obj5;
                    map = map4;
                    view2 = view12;
                } else {
                    ArrayList arrayList11 = new ArrayList();
                    Object obj6 = obj4;
                    captureTransitioningViews(arrayList11, operation10.getFragment().mView);
                    if (z8) {
                        if (operation10 == operation9) {
                            arrayList11.removeAll(arrayList4);
                        } else {
                            arrayList11.removeAll(arrayList9);
                        }
                    }
                    if (arrayList11.isEmpty()) {
                        fragmentTransitionImpl3.addTarget(cloneTransition, view13);
                        view = view13;
                        arrayList = arrayList4;
                        arrayList2 = arrayList9;
                        operation3 = operation10;
                        obj2 = obj5;
                        map = map4;
                        obj = obj6;
                    } else {
                        fragmentTransitionImpl3.addTargets(cloneTransition, arrayList11);
                        view = view13;
                        obj = obj6;
                        arrayList = arrayList4;
                        obj2 = obj5;
                        arrayList2 = arrayList9;
                        map = map4;
                        fragmentTransitionImpl3.scheduleRemoveTargets(cloneTransition, cloneTransition, arrayList11, null, null, null, null);
                        if (operation10.getFinalState() == SpecialEffectsController.Operation.State.GONE) {
                            operation3 = operation10;
                            list2.remove(operation3);
                            fragmentTransitionImpl3.scheduleHideFragmentView(cloneTransition, operation3.getFragment().mView, arrayList11);
                            OneShotPreDrawListener.add(getContainer(), new 8(arrayList11));
                        } else {
                            operation3 = operation10;
                        }
                    }
                    if (operation3.getFinalState() == SpecialEffectsController.Operation.State.VISIBLE) {
                        arrayList10.addAll(arrayList11);
                        if (z6) {
                            fragmentTransitionImpl3.setEpicenter(cloneTransition, rect5);
                        }
                        view2 = view12;
                    } else {
                        view2 = view12;
                        fragmentTransitionImpl3.setEpicenter(cloneTransition, view2);
                    }
                    map.put(operation3, true);
                    if (transitionInfo4.isOverlapAllowed()) {
                        obj2 = fragmentTransitionImpl3.mergeTransitionsTogether(obj2, cloneTransition, null);
                    } else {
                        obj = fragmentTransitionImpl3.mergeTransitionsTogether(obj, cloneTransition, null);
                    }
                }
                it6 = it7;
                obj4 = obj;
                obj5 = obj2;
                map4 = map;
                view12 = view2;
                view13 = view;
                arrayList4 = arrayList;
                arrayList9 = arrayList2;
                z7 = false;
            }
        }
        ArrayList arrayList12 = arrayList4;
        ArrayList arrayList13 = arrayList9;
        Map map5 = map4;
        Object mergeTransitionsInSequence = fragmentTransitionImpl3.mergeTransitionsInSequence(obj5, obj4, obj3);
        Iterator it8 = list.iterator();
        while (it8.hasNext()) {
            TransitionInfo transitionInfo5 = (TransitionInfo) it8.next();
            if (!transitionInfo5.isVisibilityUnchanged()) {
                Object transition = transitionInfo5.getTransition();
                SpecialEffectsController.Operation operation11 = transitionInfo5.getOperation();
                boolean z9 = obj3 != null && (operation11 == operation9 || operation11 == operation8);
                if (transition != null || z9) {
                    if (!ViewCompat.isLaidOut(getContainer())) {
                        if (FragmentManager.isLoggingEnabled(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Container " + getContainer() + " has not been laid out. Completing operation " + operation11);
                        }
                        transitionInfo5.completeSpecialEffect();
                    } else {
                        fragmentTransitionImpl3.setListenerForTransitionEnd(transitionInfo5.getOperation().getFragment(), mergeTransitionsInSequence, transitionInfo5.getSignal(), new 9(transitionInfo5));
                    }
                }
            }
        }
        if (!ViewCompat.isLaidOut(getContainer())) {
            return map5;
        }
        FragmentTransition.setViewVisibility(arrayList10, 4);
        ArrayList prepareSetNameOverridesReordered = fragmentTransitionImpl3.prepareSetNameOverridesReordered(arrayList13);
        fragmentTransitionImpl3.beginDelayedTransition(getContainer(), mergeTransitionsInSequence);
        fragmentTransitionImpl3.setNameOverridesReordered(getContainer(), arrayList12, arrayList13, prepareSetNameOverridesReordered, arrayMap5);
        FragmentTransition.setViewVisibility(arrayList10, 0);
        fragmentTransitionImpl3.swapSharedElementTargets(obj3, arrayList12, arrayList13);
        return map5;
    }

    class 6 implements Runnable {
        final /* synthetic */ SpecialEffectsController.Operation val$firstOut;
        final /* synthetic */ boolean val$isPop;
        final /* synthetic */ SpecialEffectsController.Operation val$lastIn;
        final /* synthetic */ ArrayMap val$lastInViews;

        6(SpecialEffectsController.Operation operation, SpecialEffectsController.Operation operation2, boolean z, ArrayMap arrayMap) {
            this.val$lastIn = operation;
            this.val$firstOut = operation2;
            this.val$isPop = z;
            this.val$lastInViews = arrayMap;
        }

        public void run() {
            FragmentTransition.callSharedElementStartEnd(this.val$lastIn.getFragment(), this.val$firstOut.getFragment(), this.val$isPop, this.val$lastInViews, false);
        }
    }

    class 7 implements Runnable {
        final /* synthetic */ FragmentTransitionImpl val$impl;
        final /* synthetic */ Rect val$lastInEpicenterRect;
        final /* synthetic */ View val$lastInEpicenterView;

        7(FragmentTransitionImpl fragmentTransitionImpl, View view, Rect rect) {
            this.val$impl = fragmentTransitionImpl;
            this.val$lastInEpicenterView = view;
            this.val$lastInEpicenterRect = rect;
        }

        public void run() {
            this.val$impl.getBoundsOnScreen(this.val$lastInEpicenterView, this.val$lastInEpicenterRect);
        }
    }

    class 8 implements Runnable {
        final /* synthetic */ ArrayList val$transitioningViews;

        8(ArrayList arrayList) {
            this.val$transitioningViews = arrayList;
        }

        public void run() {
            FragmentTransition.setViewVisibility(this.val$transitioningViews, 4);
        }
    }

    class 9 implements Runnable {
        final /* synthetic */ TransitionInfo val$transitionInfo;

        9(TransitionInfo transitionInfo) {
            this.val$transitionInfo = transitionInfo;
        }

        public void run() {
            this.val$transitionInfo.completeSpecialEffect();
        }
    }

    void retainMatchingViews(ArrayMap arrayMap, Collection collection) {
        Iterator it = arrayMap.entrySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(ViewCompat.getTransitionName((View) ((Map.Entry) it.next()).getValue()))) {
                it.remove();
            }
        }
    }

    void captureTransitioningViews(ArrayList arrayList, View view) {
        if (view instanceof ViewGroup) {
            if (!arrayList.contains(view) && ViewCompat.getTransitionName(view) != null) {
                arrayList.add(view);
            }
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int r1 = 0; r1 < childCount; r1++) {
                View childAt = viewGroup.getChildAt(r1);
                if (childAt.getVisibility() == 0) {
                    captureTransitioningViews(arrayList, childAt);
                }
            }
            return;
        }
        if (arrayList.contains(view)) {
            return;
        }
        arrayList.add(view);
    }

    void findNamedViews(Map map, View view) {
        String transitionName = ViewCompat.getTransitionName(view);
        if (transitionName != null) {
            map.put(transitionName, view);
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int r1 = 0; r1 < childCount; r1++) {
                View childAt = viewGroup.getChildAt(r1);
                if (childAt.getVisibility() == 0) {
                    findNamedViews(map, childAt);
                }
            }
        }
    }

    void applyContainerChanges(SpecialEffectsController.Operation operation) {
        operation.getFinalState().applyState(operation.getFragment().mView);
    }

    private static class SpecialEffectsInfo {
        private final SpecialEffectsController.Operation mOperation;
        private final CancellationSignal mSignal;

        SpecialEffectsInfo(SpecialEffectsController.Operation operation, CancellationSignal cancellationSignal) {
            this.mOperation = operation;
            this.mSignal = cancellationSignal;
        }

        SpecialEffectsController.Operation getOperation() {
            return this.mOperation;
        }

        CancellationSignal getSignal() {
            return this.mSignal;
        }

        boolean isVisibilityUnchanged() {
            SpecialEffectsController.Operation.State from = SpecialEffectsController.Operation.State.from(this.mOperation.getFragment().mView);
            SpecialEffectsController.Operation.State finalState = this.mOperation.getFinalState();
            return from == finalState || !(from == SpecialEffectsController.Operation.State.VISIBLE || finalState == SpecialEffectsController.Operation.State.VISIBLE);
        }

        void completeSpecialEffect() {
            this.mOperation.completeSpecialEffect(this.mSignal);
        }
    }

    private static class AnimationInfo extends SpecialEffectsInfo {
        private FragmentAnim.AnimationOrAnimator mAnimation;
        private boolean mIsPop;
        private boolean mLoadedAnim;

        AnimationInfo(SpecialEffectsController.Operation operation, CancellationSignal cancellationSignal, boolean z) {
            super(operation, cancellationSignal);
            this.mLoadedAnim = false;
            this.mIsPop = z;
        }

        FragmentAnim.AnimationOrAnimator getAnimation(Context context) {
            if (this.mLoadedAnim) {
                return this.mAnimation;
            }
            FragmentAnim.AnimationOrAnimator loadAnimation = FragmentAnim.loadAnimation(context, getOperation().getFragment(), getOperation().getFinalState() == SpecialEffectsController.Operation.State.VISIBLE, this.mIsPop);
            this.mAnimation = loadAnimation;
            this.mLoadedAnim = true;
            return loadAnimation;
        }
    }

    private static class TransitionInfo extends SpecialEffectsInfo {
        private final boolean mOverlapAllowed;
        private final Object mSharedElementTransition;
        private final Object mTransition;

        TransitionInfo(SpecialEffectsController.Operation operation, CancellationSignal cancellationSignal, boolean z, boolean z2) {
            Object exitTransition;
            Object enterTransition;
            boolean allowEnterTransitionOverlap;
            super(operation, cancellationSignal);
            if (operation.getFinalState() == SpecialEffectsController.Operation.State.VISIBLE) {
                if (z) {
                    enterTransition = operation.getFragment().getReenterTransition();
                } else {
                    enterTransition = operation.getFragment().getEnterTransition();
                }
                this.mTransition = enterTransition;
                if (z) {
                    allowEnterTransitionOverlap = operation.getFragment().getAllowReturnTransitionOverlap();
                } else {
                    allowEnterTransitionOverlap = operation.getFragment().getAllowEnterTransitionOverlap();
                }
                this.mOverlapAllowed = allowEnterTransitionOverlap;
            } else {
                if (z) {
                    exitTransition = operation.getFragment().getReturnTransition();
                } else {
                    exitTransition = operation.getFragment().getExitTransition();
                }
                this.mTransition = exitTransition;
                this.mOverlapAllowed = true;
            }
            if (!z2) {
                this.mSharedElementTransition = null;
            } else if (z) {
                this.mSharedElementTransition = operation.getFragment().getSharedElementReturnTransition();
            } else {
                this.mSharedElementTransition = operation.getFragment().getSharedElementEnterTransition();
            }
        }

        Object getTransition() {
            return this.mTransition;
        }

        boolean isOverlapAllowed() {
            return this.mOverlapAllowed;
        }

        public boolean hasSharedElementTransition() {
            return this.mSharedElementTransition != null;
        }

        public Object getSharedElementTransition() {
            return this.mSharedElementTransition;
        }

        FragmentTransitionImpl getHandlingImpl() {
            FragmentTransitionImpl handlingImpl = getHandlingImpl(this.mTransition);
            FragmentTransitionImpl handlingImpl2 = getHandlingImpl(this.mSharedElementTransition);
            if (handlingImpl == null || handlingImpl2 == null || handlingImpl == handlingImpl2) {
                return handlingImpl != null ? handlingImpl : handlingImpl2;
            }
            throw new IllegalArgumentException("Mixing framework transitions and AndroidX transitions is not allowed. Fragment " + getOperation().getFragment() + " returned Transition " + this.mTransition + " which uses a different Transition  type than its shared element transition " + this.mSharedElementTransition);
        }

        private FragmentTransitionImpl getHandlingImpl(Object obj) {
            if (obj == null) {
                return null;
            }
            if (FragmentTransition.PLATFORM_IMPL != null && FragmentTransition.PLATFORM_IMPL.canHandle(obj)) {
                return FragmentTransition.PLATFORM_IMPL;
            }
            if (FragmentTransition.SUPPORT_IMPL != null && FragmentTransition.SUPPORT_IMPL.canHandle(obj)) {
                return FragmentTransition.SUPPORT_IMPL;
            }
            throw new IllegalArgumentException("Transition " + obj + " for fragment " + getOperation().getFragment() + " is not a valid framework Transition or AndroidX Transition");
        }
    }
}
