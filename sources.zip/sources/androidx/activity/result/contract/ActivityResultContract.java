package androidx.activity.result.contract;

import android.content.Context;
import android.content.Intent;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public abstract class ActivityResultContract {
    public abstract Intent createIntent(Context context, Object obj);

    public SynchronousResult getSynchronousResult(Context context, Object obj) {
        return null;
    }

    public abstract Object parseResult(int r1, Intent intent);

    public static final class SynchronousResult {
        private final Object mValue;

        public SynchronousResult(Object obj) {
            this.mValue = obj;
        }

        public Object getValue() {
            return this.mValue;
        }
    }
}
