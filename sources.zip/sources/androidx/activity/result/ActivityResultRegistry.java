package androidx.activity.result;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.core.app.ActivityOptionsCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

/* loaded from: /storage/emulated/0/Android/data/com.apktools.app.decompile/files/decompile_out/com.cl.bridge/classes.dex */
public abstract class ActivityResultRegistry {
    private static final int INITIAL_REQUEST_CODE_VALUE = 65536;
    private static final String KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS = "KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS";
    private static final String KEY_COMPONENT_ACTIVITY_PENDING_RESULTS = "KEY_COMPONENT_ACTIVITY_PENDING_RESULT";
    private static final String KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT = "KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT";
    private static final String KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS = "KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS";
    private static final String KEY_COMPONENT_ACTIVITY_REGISTERED_RCS = "KEY_COMPONENT_ACTIVITY_REGISTERED_RCS";
    private static final String LOG_TAG = "ActivityResultRegistry";
    private Random mRandom = new Random();
    private final Map mRcToKey = new HashMap();
    private final Map mKeyToRc = new HashMap();
    private final Map mKeyToLifecycleContainers = new HashMap();
    ArrayList mLaunchedKeys = new ArrayList();
    final transient Map mKeyToCallback = new HashMap();
    final Map mParsedPendingResults = new HashMap();
    final Bundle mPendingResults = new Bundle();

    public abstract void onLaunch(int r1, ActivityResultContract activityResultContract, Object obj, ActivityOptionsCompat activityOptionsCompat);

    public final ActivityResultLauncher register(String str, LifecycleOwner lifecycleOwner, ActivityResultContract activityResultContract, ActivityResultCallback activityResultCallback) {
        Lifecycle lifecycle = lifecycleOwner.getLifecycle();
        if (lifecycle.getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
            throw new IllegalStateException("LifecycleOwner " + lifecycleOwner + " is attempting to register while current state is " + lifecycle.getCurrentState() + ". LifecycleOwners must call register before they are STARTED.");
        }
        int registerKey = registerKey(str);
        LifecycleContainer lifecycleContainer = (LifecycleContainer) this.mKeyToLifecycleContainers.get(str);
        if (lifecycleContainer == null) {
            lifecycleContainer = new LifecycleContainer(lifecycle);
        }
        lifecycleContainer.addObserver(new 1(str, activityResultCallback, activityResultContract));
        this.mKeyToLifecycleContainers.put(str, lifecycleContainer);
        return new 2(str, registerKey, activityResultContract);
    }

    class 1 implements LifecycleEventObserver {
        final /* synthetic */ ActivityResultCallback val$callback;
        final /* synthetic */ ActivityResultContract val$contract;
        final /* synthetic */ String val$key;

        1(String str, ActivityResultCallback activityResultCallback, ActivityResultContract activityResultContract) {
            this.val$key = str;
            this.val$callback = activityResultCallback;
            this.val$contract = activityResultContract;
        }

        public void onStateChanged(LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
            if (Lifecycle.Event.ON_START.equals(event)) {
                ActivityResultRegistry.this.mKeyToCallback.put(this.val$key, new CallbackAndContract(this.val$callback, this.val$contract));
                if (ActivityResultRegistry.this.mParsedPendingResults.containsKey(this.val$key)) {
                    Object obj = ActivityResultRegistry.this.mParsedPendingResults.get(this.val$key);
                    ActivityResultRegistry.this.mParsedPendingResults.remove(this.val$key);
                    this.val$callback.onActivityResult(obj);
                }
                ActivityResult activityResult = (ActivityResult) ActivityResultRegistry.this.mPendingResults.getParcelable(this.val$key);
                if (activityResult != null) {
                    ActivityResultRegistry.this.mPendingResults.remove(this.val$key);
                    this.val$callback.onActivityResult(this.val$contract.parseResult(activityResult.getResultCode(), activityResult.getData()));
                    return;
                }
                return;
            }
            if (Lifecycle.Event.ON_STOP.equals(event)) {
                ActivityResultRegistry.this.mKeyToCallback.remove(this.val$key);
            } else if (Lifecycle.Event.ON_DESTROY.equals(event)) {
                ActivityResultRegistry.this.unregister(this.val$key);
            }
        }
    }

    class 2 extends ActivityResultLauncher {
        final /* synthetic */ ActivityResultContract val$contract;
        final /* synthetic */ String val$key;
        final /* synthetic */ int val$requestCode;

        2(String str, int r3, ActivityResultContract activityResultContract) {
            this.val$key = str;
            this.val$requestCode = r3;
            this.val$contract = activityResultContract;
        }

        public void launch(Object obj, ActivityOptionsCompat activityOptionsCompat) {
            ActivityResultRegistry.this.mLaunchedKeys.add(this.val$key);
            ActivityResultRegistry.this.onLaunch(this.val$requestCode, this.val$contract, obj, activityOptionsCompat);
        }

        public void unregister() {
            ActivityResultRegistry.this.unregister(this.val$key);
        }

        public ActivityResultContract getContract() {
            return this.val$contract;
        }
    }

    public final ActivityResultLauncher register(String str, ActivityResultContract activityResultContract, ActivityResultCallback activityResultCallback) {
        int registerKey = registerKey(str);
        this.mKeyToCallback.put(str, new CallbackAndContract(activityResultCallback, activityResultContract));
        if (this.mParsedPendingResults.containsKey(str)) {
            Object obj = this.mParsedPendingResults.get(str);
            this.mParsedPendingResults.remove(str);
            activityResultCallback.onActivityResult(obj);
        }
        ActivityResult activityResult = (ActivityResult) this.mPendingResults.getParcelable(str);
        if (activityResult != null) {
            this.mPendingResults.remove(str);
            activityResultCallback.onActivityResult(activityResultContract.parseResult(activityResult.getResultCode(), activityResult.getData()));
        }
        return new 3(str, registerKey, activityResultContract);
    }

    class 3 extends ActivityResultLauncher {
        final /* synthetic */ ActivityResultContract val$contract;
        final /* synthetic */ String val$key;
        final /* synthetic */ int val$requestCode;

        3(String str, int r3, ActivityResultContract activityResultContract) {
            this.val$key = str;
            this.val$requestCode = r3;
            this.val$contract = activityResultContract;
        }

        public void launch(Object obj, ActivityOptionsCompat activityOptionsCompat) {
            ActivityResultRegistry.this.mLaunchedKeys.add(this.val$key);
            ActivityResultRegistry.this.onLaunch(this.val$requestCode, this.val$contract, obj, activityOptionsCompat);
        }

        public void unregister() {
            ActivityResultRegistry.this.unregister(this.val$key);
        }

        public ActivityResultContract getContract() {
            return this.val$contract;
        }
    }

    final void unregister(String str) {
        Integer num;
        if (!this.mLaunchedKeys.contains(str) && (num = (Integer) this.mKeyToRc.remove(str)) != null) {
            this.mRcToKey.remove(num);
        }
        this.mKeyToCallback.remove(str);
        if (this.mParsedPendingResults.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.mParsedPendingResults.get(str));
            this.mParsedPendingResults.remove(str);
        }
        if (this.mPendingResults.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.mPendingResults.getParcelable(str));
            this.mPendingResults.remove(str);
        }
        LifecycleContainer lifecycleContainer = (LifecycleContainer) this.mKeyToLifecycleContainers.get(str);
        if (lifecycleContainer != null) {
            lifecycleContainer.clearObservers();
            this.mKeyToLifecycleContainers.remove(str);
        }
    }

    public final void onSaveInstanceState(Bundle bundle) {
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList(this.mRcToKey.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList(this.mRcToKey.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList(this.mLaunchedKeys));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) this.mPendingResults.clone());
        bundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.mRandom);
    }

    public final void onRestoreInstanceState(Bundle bundle) {
        if (bundle == null) {
            return;
        }
        ArrayList integerArrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
        ArrayList stringArrayList = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
        if (stringArrayList == null || integerArrayList == null) {
            return;
        }
        int size = stringArrayList.size();
        for (int r3 = 0; r3 < size; r3++) {
            bindRcKey(((Integer) integerArrayList.get(r3)).intValue(), (String) stringArrayList.get(r3));
        }
        this.mLaunchedKeys = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
        this.mRandom = bundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
        this.mPendingResults.putAll(bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
    }

    public final boolean dispatchResult(int r2, int r3, Intent intent) {
        String str = (String) this.mRcToKey.get(Integer.valueOf(r2));
        if (str == null) {
            return false;
        }
        this.mLaunchedKeys.remove(str);
        doDispatch(str, r3, intent, (CallbackAndContract) this.mKeyToCallback.get(str));
        return true;
    }

    public final boolean dispatchResult(int r3, Object obj) {
        String str = (String) this.mRcToKey.get(Integer.valueOf(r3));
        if (str == null) {
            return false;
        }
        this.mLaunchedKeys.remove(str);
        CallbackAndContract callbackAndContract = (CallbackAndContract) this.mKeyToCallback.get(str);
        if (callbackAndContract == null || callbackAndContract.mCallback == null) {
            this.mPendingResults.remove(str);
            this.mParsedPendingResults.put(str, obj);
            return true;
        }
        callbackAndContract.mCallback.onActivityResult(obj);
        return true;
    }

    private void doDispatch(String str, int r3, Intent intent, CallbackAndContract callbackAndContract) {
        if (callbackAndContract != null && callbackAndContract.mCallback != null) {
            callbackAndContract.mCallback.onActivityResult(callbackAndContract.mContract.parseResult(r3, intent));
        } else {
            this.mParsedPendingResults.remove(str);
            this.mPendingResults.putParcelable(str, new ActivityResult(r3, intent));
        }
    }

    private int registerKey(String str) {
        Integer num = (Integer) this.mKeyToRc.get(str);
        if (num != null) {
            return num.intValue();
        }
        int generateRandomNumber = generateRandomNumber();
        bindRcKey(generateRandomNumber, str);
        return generateRandomNumber;
    }

    private int generateRandomNumber() {
        int nextInt = this.mRandom.nextInt(2147418112);
        while (true) {
            int r0 = nextInt + 65536;
            if (!this.mRcToKey.containsKey(Integer.valueOf(r0))) {
                return r0;
            }
            nextInt = this.mRandom.nextInt(2147418112);
        }
    }

    private void bindRcKey(int r3, String str) {
        this.mRcToKey.put(Integer.valueOf(r3), str);
        this.mKeyToRc.put(str, Integer.valueOf(r3));
    }

    private static class CallbackAndContract {
        final ActivityResultCallback mCallback;
        final ActivityResultContract mContract;

        CallbackAndContract(ActivityResultCallback activityResultCallback, ActivityResultContract activityResultContract) {
            this.mCallback = activityResultCallback;
            this.mContract = activityResultContract;
        }
    }

    private static class LifecycleContainer {
        final Lifecycle mLifecycle;
        private final ArrayList mObservers = new ArrayList();

        LifecycleContainer(Lifecycle lifecycle) {
            this.mLifecycle = lifecycle;
        }

        void addObserver(LifecycleEventObserver lifecycleEventObserver) {
            this.mLifecycle.addObserver(lifecycleEventObserver);
            this.mObservers.add(lifecycleEventObserver);
        }

        void clearObservers() {
            Iterator it = this.mObservers.iterator();
            while (it.hasNext()) {
                this.mLifecycle.removeObserver((LifecycleEventObserver) it.next());
            }
            this.mObservers.clear();
        }
    }
}
